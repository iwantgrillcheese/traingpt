'use client';

import { useRouter } from 'next/navigation';
import Footer from './components/footer';
import BlogPreview from './components/blog/BlogPreview';

const HERO_IMAGE =
  'https://images.unsplash.com/photo-1541625602330-2277a4c46182?auto=format&fit=crop&w=2200&q=85';
const SWIM_IMAGE =
  'https://images.unsplash.com/photo-1530549387789-4c1017266635?auto=format&fit=crop&w=1800&q=85';
const BIKE_IMAGE =
  'https://images.unsplash.com/photo-1541625602330-2277a4c46182?auto=format&fit=crop&w=1800&q=85';
const RUN_IMAGE =
  'https://images.unsplash.com/photo-1552674605-db6ffd4facb5?auto=format&fit=crop&w=1800&q=85';

function cx(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(' ');
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-[11px] font-medium uppercase tracking-[0.2em] text-zinc-500">
      {children}
    </p>
  );
}

function MarketingHeader({ onStart }: { onStart: () => void }) {
  const navItems = [
    { href: '#plan', label: 'Plan' },
    { href: '#schedule', label: 'Schedule' },
    { href: '#coaching', label: 'Coaching' },
    { href: '#resources', label: 'Resources' },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-zinc-200/80 bg-[#fbfaf8]/90 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="flex items-center gap-3"
          aria-label="Go to top"
        >
          <span className="text-sm font-semibold tracking-tight text-zinc-950">TrainGPT</span>
        </button>

        <nav className="hidden items-center gap-1 md:flex">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-full px-3 py-2 text-sm text-zinc-600 transition hover:bg-zinc-100 hover:text-zinc-950"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <button
          type="button"
          onClick={onStart}
          className="rounded-full bg-zinc-950 px-4 py-2 text-sm font-semibold text-white transition hover:bg-zinc-800"
        >
          Log in to generate plan
        </button>
      </div>
    </header>
  );
}

function ProductPreview() {
  const sessions = [
    ['Mon', 'Swim', '2,000m technique', 'Done'],
    ['Tue', 'Bike', '75min endurance', 'Planned'],
    ['Wed', 'Run', '45min tempo', 'Planned'],
    ['Sat', 'Brick', 'Bike + run transition', 'Key'],
  ];

  return (
    <div className="rounded-[2rem] border border-zinc-200 bg-white/95 p-4 shadow-[0_24px_90px_rgba(24,24,27,0.12)] backdrop-blur md:p-5">
      <div className="flex items-center justify-between border-b border-zinc-100 pb-4">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-zinc-400">Generated schedule</p>
          <h3 className="mt-1 text-lg font-semibold tracking-tight text-zinc-950">May 25 – May 31</h3>
        </div>
        <span className="rounded-full bg-zinc-950 px-3 py-1 text-xs font-medium text-white">Race build</span>
      </div>

      <div className="mt-4 space-y-2">
        {sessions.map(([day, sport, title, status]) => (
          <div
            key={`${day}-${sport}`}
            className="flex items-center justify-between rounded-2xl border border-zinc-200 bg-[#fbfaf8] px-3 py-3"
          >
            <div className="flex min-w-0 items-center gap-3">
              <span className="w-9 shrink-0 text-xs font-medium text-zinc-400">{day}</span>
              <span className="h-2 w-2 shrink-0 rounded-full bg-zinc-950" />
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-zinc-950">{sport}</p>
                <p className="truncate text-xs text-zinc-500">{title}</p>
              </div>
            </div>
            <span className="ml-3 shrink-0 rounded-full bg-white px-2.5 py-1 text-[11px] font-medium text-zinc-600 ring-1 ring-zinc-200">
              {status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ImagePanel({ image, label, title }: { image: string; label: string; title: string }) {
  return (
    <div className="group relative min-h-[360px] overflow-hidden rounded-[2rem] bg-zinc-200 md:min-h-[520px]">
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
        style={{ backgroundImage: `url(${image})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-6 text-white md:p-8">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-white/70">{label}</p>
        <h3 className="mt-3 max-w-md text-2xl font-semibold tracking-tight md:text-3xl">{title}</h3>
      </div>
    </div>
  );
}

function HowItWorks() {
  const steps = [
    {
      number: '01',
      title: 'Log in and set your race.',
      copy: 'Choose your distance, race date, weekly hours, experience, and the constraints that matter.',
    },
    {
      number: '02',
      title: 'Generate the plan.',
      copy: 'TrainGPT builds a periodized swim, bike, and run schedule with recovery, long sessions, and key bricks.',
    },
    {
      number: '03',
      title: 'Follow the week.',
      copy: 'Use the calendar, sync Strava, generate detailed workouts, and review your training as the plan unfolds.',
    },
  ];

  return (
    <section id="how-it-works" className="border-t border-zinc-200 bg-[#fbfaf8] px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="max-w-2xl">
          <SectionLabel>How it works</SectionLabel>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-zinc-950 md:text-5xl">
            From blank calendar to race-ready structure.
          </h2>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-3">
          {steps.map((step) => (
            <div key={step.number} className="rounded-[1.75rem] border border-zinc-200 bg-white p-6 shadow-sm">
              <p className="text-xs font-medium text-zinc-400">{step.number}</p>
              <h3 className="mt-10 text-xl font-semibold tracking-tight text-zinc-950">{step.title}</h3>
              <p className="mt-3 text-sm leading-6 text-zinc-600">{step.copy}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FeatureStrip() {
  const items = [
    ['Personalized plan', 'Built around your race, schedule, and experience.'],
    ['Clear calendar', 'Every session has a place, purpose, and progression.'],
    ['Strava tracking', 'Completed workouts appear alongside the plan.'],
    ['Weekly guidance', 'Review the week and know what matters next.'],
  ];

  return (
    <section className="border-y border-zinc-200 bg-white px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-7xl gap-4 md:grid-cols-4">
        {items.map(([title, copy]) => (
          <div key={title} className="flex gap-3">
            <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-zinc-950" />
            <div>
              <p className="text-sm font-semibold text-zinc-950">{title}</p>
              <p className="mt-1 text-sm leading-5 text-zinc-500">{copy}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function Home() {
  const router = useRouter();

  const startPlan = () => {
    router.push(`/login?next=${encodeURIComponent('/plan')}`);
  };

  return (
    <main className="min-h-screen bg-[#fbfaf8] text-zinc-950">
      <MarketingHeader onStart={startPlan} />

      <section className="relative overflow-hidden px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-12">
          <div className="lg:col-span-6">
            <SectionLabel>Personalized triathlon planning</SectionLabel>
            <h1 className="mt-5 max-w-4xl text-5xl font-semibold tracking-[-0.055em] text-zinc-950 sm:text-6xl lg:text-7xl">
              Your triathlon training plan, generated in seconds.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-zinc-600">
              Build a personalized swim, bike, and run schedule around your race, weekly availability, and current fitness. Then follow it with Strava-connected tracking and weekly coaching guidance.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={startPlan}
                className="rounded-full bg-zinc-950 px-6 py-3 text-sm font-semibold text-white transition hover:bg-zinc-800"
              >
                Log in to generate your plan
              </button>
              <a
                href="#how-it-works"
                className="rounded-full border border-zinc-300 bg-white px-6 py-3 text-center text-sm font-semibold text-zinc-950 transition hover:bg-zinc-50"
              >
                See how it works
              </a>
            </div>

            <div className="mt-10 grid max-w-lg grid-cols-3 gap-6 border-t border-zinc-200 pt-6">
              <div>
                <p className="text-2xl font-semibold">4</p>
                <p className="mt-1 text-xs text-zinc-500">Race distances</p>
              </div>
              <div>
                <p className="text-2xl font-semibold">3</p>
                <p className="mt-1 text-xs text-zinc-500">Sports balanced</p>
              </div>
              <div>
                <p className="text-2xl font-semibold">1</p>
                <p className="mt-1 text-xs text-zinc-500">Clear calendar</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative">
              <div className="overflow-hidden rounded-[2.5rem] border border-zinc-200 bg-zinc-200 shadow-sm">
                <div
                  className="min-h-[420px] bg-cover bg-center md:min-h-[620px]"
                  style={{ backgroundImage: `url(${HERO_IMAGE})` }}
                />
              </div>
              <div className="absolute -bottom-8 left-4 right-4 md:left-auto md:right-8 md:w-[430px]">
                <ProductPreview />
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="h-10 md:h-16" />

      <FeatureStrip />

      <section className="bg-[#fbfaf8] px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-4 md:grid-cols-3">
          <ImagePanel image={SWIM_IMAGE} label="Swim" title="Build technique and endurance without guessing what belongs in the week." />
          <ImagePanel image={BIKE_IMAGE} label="Bike" title="Structure long rides, bricks, and intensity around the race you actually have." />
          <ImagePanel image={RUN_IMAGE} label="Run" title="Progress the run safely while balancing the fatigue of swim and bike training." />
        </div>
      </section>

      <HowItWorks />

      <section id="schedule" className="bg-white px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <SectionLabel>Training calendar</SectionLabel>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-zinc-950 md:text-5xl">
              Know exactly what to train each day.
            </h2>
            <p className="mt-5 text-base leading-8 text-zinc-600">
              Every generated plan becomes a simple calendar with daily sessions, detailed workout generation, completion tracking, and Strava activity overlays.
            </p>
          </div>
          <div className="lg:col-span-7">
            <ProductPreview />
          </div>
        </div>
      </section>

      <section id="coaching" className="border-y border-zinc-200 bg-[#fbfaf8] px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-12">
          <div className="lg:col-span-6">
            <div className="rounded-[2rem] border border-zinc-200 bg-white p-6 shadow-sm">
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-zinc-400">Weekly review</p>
              <h3 className="mt-4 text-2xl font-semibold tracking-tight text-zinc-950">
                Understand what changed, what mattered, and what to focus on next.
              </h3>
              <div className="mt-6 space-y-3">
                {[
                  'Time trained: compare planned volume to completed training.',
                  'Key sessions: identify the workouts that matter most this week.',
                  'Next focus: keep the plan aligned with your recent training.',
                ].map((item) => (
                  <div key={item} className="rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm text-zinc-700">
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="lg:col-span-5 lg:col-start-8">
            <SectionLabel>Coaching guidance</SectionLabel>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-zinc-950 md:text-5xl">
              Review the week before the next one begins.
            </h2>
            <p className="mt-5 text-base leading-8 text-zinc-600">
              Check in each week, review completed training against the plan, and keep your next sessions focused on race-day progress.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-zinc-950 px-4 py-20 text-white sm:px-6 lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 md:flex-row md:items-end">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-white/50">Start training</p>
            <h2 className="mt-4 max-w-3xl text-4xl font-semibold tracking-tight md:text-6xl">
              Build your next race plan in seconds.
            </h2>
          </div>
          <button
            type="button"
            onClick={startPlan}
            className="rounded-full bg-white px-6 py-3 text-sm font-semibold text-zinc-950 transition hover:bg-white/90"
          >
            Log in to generate your plan
          </button>
        </div>
      </section>

      <section id="resources" className="bg-white">
        <BlogPreview />
      </section>

      <Footer />
    </main>
  );
}
