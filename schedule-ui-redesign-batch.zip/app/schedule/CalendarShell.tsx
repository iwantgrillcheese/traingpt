'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import type { SVGProps } from 'react';
import {
  addMonths,
  endOfWeek,
  format,
  isAfter,
  parseISO,
  startOfMonth,
  startOfWeek,
  subDays,
  subMonths,
} from 'date-fns';
import {
  DndContext,
  MouseSensor,
  TouchSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type SensorOptions,
} from '@dnd-kit/core';

import MonthGrid from './MonthGrid';
import MobileCalendarView from './MobileCalendarView';
import SessionModal from './SessionModal';
import StravaActivityModal from './StravaActivityModal';
import AddSessionModalTP from './AddSessionModalTP';

import type { MergedSession } from '@/utils/mergeSessionWithStrava';
import type { StravaActivity } from '@/types/strava';
import { normalizeStravaActivities } from '@/utils/normalizeStravaActivities';
import { supabase } from '@/lib/supabase/client';
import type { CompletedSession } from '@/types/session';

type CalendarShellProps = {
  sessions: MergedSession[];
  completedSessions: CompletedSession[];
  extraStravaActivities?: StravaActivity[];
  onCompletedUpdateAction?: (updated: CompletedSession[]) => void;
  timezone?: string;
  todaySummary?: string;
  nextSummary?: string;
  weekPhaseSummary?: string;
  raceGoal?: string | null;
  onOpenWalkthroughAction?: () => void;
  walkthroughLoading?: boolean;
};

function IconChevronLeft(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" {...props}>
      <path
        d="M12.5 4.5L7.5 10l5 5.5"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function IconChevronRight(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 20 20" fill="none" aria-hidden="true" {...props}>
      <path
        d="M7.5 4.5l5 5.5-5 5.5"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function Toolbar({
  currentMonth,
  onPrev,
  onNext,
  onToday,
  onOpenWalkthrough,
  walkthroughLoading,
}: {
  currentMonth: Date;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
  onOpenWalkthrough?: () => void;
  walkthroughLoading?: boolean;
}) {
  return (
    <div className="sticky top-0 z-30 border-b border-black/10 bg-white">
      <div className="w-full px-4 lg:px-6">
        <div className="flex h-14 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-[15px] font-semibold tracking-tight text-zinc-950">
              {format(currentMonth, 'MMMM yyyy')}
            </div>

            <div className="h-5 w-px bg-black/10" />

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onToday}
                className="h-9 rounded-md border border-black/10 bg-white px-3 text-[13px] font-medium text-zinc-700 hover:bg-zinc-50"
              >
                Today
              </button>

              <button
                type="button"
                onClick={onPrev}
                className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-black/10 bg-white text-zinc-700 hover:bg-zinc-50"
                aria-label="Previous month"
              >
                <IconChevronLeft className="h-5 w-5" />
              </button>

              <button
                type="button"
                onClick={onNext}
                className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-black/10 bg-white text-zinc-700 hover:bg-zinc-50"
                aria-label="Next month"
              >
                <IconChevronRight className="h-5 w-5" />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenWalkthrough ? (
              <button
                type="button"
                onClick={onOpenWalkthrough}
                disabled={walkthroughLoading}
                className="h-9 rounded-md border border-black/10 bg-white px-3 text-[13px] font-medium text-zinc-700 hover:bg-zinc-50 disabled:opacity-50"
              >
                {walkthroughLoading ? 'Opening…' : 'Walkthrough'}
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function CalendarShell({
  sessions,
  completedSessions,
  extraStravaActivities = [],
  onCompletedUpdateAction,
  timezone = 'America/Los_Angeles',
  todaySummary,
  nextSummary,
  weekPhaseSummary,
  raceGoal,
  onOpenWalkthroughAction,
  walkthroughLoading,
}: CalendarShellProps) {
  const [hasMounted, setHasMounted] = useState(false);
  const [isMobileView, setIsMobileView] = useState(false);

  const [selectedSession, setSelectedSession] = useState<MergedSession | null>(null);
  const [selectedActivity, setSelectedActivity] = useState<StravaActivity | null>(null);
  const [addSessionDate, setAddSessionDate] = useState<Date | null>(null);
  const [currentMonth, setCurrentMonth] = useState<Date>(startOfMonth(new Date()));

  const [completed, setCompleted] = useState<CompletedSession[]>(completedSessions);
  const [localSessions, setLocalSessions] = useState<MergedSession[]>(sessions);

  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [saveMessage, setSaveMessage] = useState('');

  useEffect(() => {
    setHasMounted(true);
  }, []);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(max-width: 767px)');

    const update = () => {
      setIsMobileView(mediaQuery.matches);
    };

    update();
    mediaQuery.addEventListener?.('change', update);

    return () => {
      mediaQuery.removeEventListener?.('change', update);
    };
  }, []);

  useEffect(() => {
    setCompleted(completedSessions);
  }, [completedSessions]);

  useEffect(() => {
    setLocalSessions(sessions);
  }, [sessions]);

  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, []);

  useEffect(() => {
    onCompletedUpdateAction?.(completed);
  }, [completed, onCompletedUpdateAction]);

  const sensors = useSensors(
    useSensor(MouseSensor, {
      activationConstraint: { distance: 8 },
    } as SensorOptions),
    useSensor(TouchSensor, {
      activationConstraint: { delay: 200, tolerance: 8 },
    } as SensorOptions)
  );

  const sessionsByDate = useMemo(() => {
    const map: Record<string, MergedSession[]> = {};

    localSessions.forEach((session) => {
      if (!session.date) return;

      if (!map[session.date]) {
        map[session.date] = [];
      }

      map[session.date].push(session);
    });

    Object.keys(map).forEach((dateKey) => {
      map[dateKey] = map[dateKey]
        .slice()
        .sort((a, b) => String(a.sport ?? '').localeCompare(String(b.sport ?? '')));
    });

    return map;
  }, [localSessions]);

  const stravaByDate: Record<string, StravaActivity[]> = useMemo(() => {
    return normalizeStravaActivities(extraStravaActivities, timezone);
  }, [extraStravaActivities, timezone]);

  const goToPrevMonth = () => setCurrentMonth((month) => subMonths(month, 1));
  const goToNextMonth = () => setCurrentMonth((month) => addMonths(month, 1));
  const goToToday = () => setCurrentMonth(startOfMonth(new Date()));

  const weekLabel = useMemo(() => {
    const now = new Date();
    const weekStart = startOfWeek(now, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(now, { weekStartsOn: 1 });

    return `${format(weekStart, 'MMM d')}–${format(weekEnd, 'MMM d')}`;
  }, []);

  const recentExecution = useMemo(() => {
    const cutoff = subDays(new Date(), 14);

    const completedKeys = new Set(
      completed
        .filter((item) => (item.status ?? 'done') === 'done')
        .map((item) => `${item.date}::${item.session_title}`)
    );

    const recentCompleted = localSessions.filter((session) => {
      if (!session.date || !session.title) return false;

      const sessionDate = parseISO(session.date);
      if (!isAfter(sessionDate, cutoff)) return false;

      return Boolean(session.stravaActivity) || completedKeys.has(`${session.date}::${session.title}`);
    }).length;

    const recentMissed = localSessions.filter((session) => {
      if (!session.date || !session.title) return false;

      const sessionDate = parseISO(session.date);

      if (isAfter(sessionDate, new Date()) || !isAfter(sessionDate, cutoff)) {
        return false;
      }

      const done =
        Boolean(session.stravaActivity) || completedKeys.has(`${session.date}::${session.title}`);

      return !done;
    }).length;

    return { recentCompleted, recentMissed };
  }, [localSessions, completed]);

  const handleSessionAdded = (newSession: MergedSession) => {
    setLocalSessions((prev) => [...prev, newSession]);
  };

  const handleSessionDeleted = (sessionId: string) => {
    setLocalSessions((prev) => prev.filter((session) => String(session.id) !== String(sessionId)));

    setSelectedSession((prev) => {
      if (!prev) return null;
      return String(prev.id) === String(sessionId) ? null : prev;
    });
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (!active || !over) return;

    const draggedId = String(active.id);
    const targetDate = String(over.id);

    let previousDate: string | null = null;

    setLocalSessions((prev) =>
      prev.map((session) => {
        if (String(session.id) !== draggedId) return session;

        previousDate = String(session.date ?? '');
        return { ...session, date: targetDate };
      })
    );

    setSaveState('saving');
    setSaveMessage('Saving schedule change…');

    if (saveTimer.current) {
      clearTimeout(saveTimer.current);
    }

    saveTimer.current = setTimeout(async () => {
      const { error } = await supabase
        .from('sessions')
        .update({ date: targetDate })
        .eq('id', draggedId);

      if (error) {
        console.error('[CalendarShell] error persisting session move:', error);

        if (previousDate) {
          setLocalSessions((prev) =>
            prev.map((session) =>
              String(session.id) === draggedId ? { ...session, date: previousDate as string } : session
            )
          );
        }

        setSaveState('error');
        setSaveMessage('Could not save this move. Reverted to original day.');
        return;
      }

      setSaveState('saved');
      setSaveMessage('Saved');

      window.setTimeout(() => {
        setSaveState('idle');
        setSaveMessage('');
      }, 1200);
    }, 450);
  };

  if (!hasMounted) {
    return <main className="min-h-[100dvh] w-full bg-white" />;
  }

  return (
    <main className="min-h-[100dvh] w-full bg-zinc-50 pb-[env(safe-area-inset-bottom)]">
      {isMobileView ? (
        <div>
          <div className="space-y-2 bg-zinc-50 px-4 pb-1 pt-3">
            {weekPhaseSummary ? (
              <div className="text-[11px] font-semibold uppercase tracking-[0.1em] text-zinc-500">
                {weekPhaseSummary}
              </div>
            ) : null}

            <div className="rounded-xl border border-black/10 bg-white px-3 py-2">
              <div className="text-[10px] uppercase tracking-wide text-zinc-500">Today</div>
              <div className="mt-1 text-[13px] font-medium text-zinc-900">
                {todaySummary ?? 'No workout scheduled today'}
              </div>
            </div>

            <div className="rounded-xl border border-black/10 bg-white px-3 py-2">
              <div className="text-[10px] uppercase tracking-wide text-zinc-500">Next</div>
              <div className="mt-1 text-[13px] font-medium text-zinc-900">
                {nextSummary ?? 'No upcoming sessions yet'}
              </div>
            </div>
          </div>

          <MobileCalendarView
            sessions={localSessions as any}
            completedSessions={completed}
            stravaActivities={extraStravaActivities}
            onSessionDeleted={handleSessionDeleted}
            weekPhase={weekPhaseSummary ?? null}
            raceGoal={raceGoal ?? null}
          />
        </div>
      ) : (
        <div>
          <Toolbar
            currentMonth={currentMonth}
            onPrev={goToPrevMonth}
            onNext={goToNextMonth}
            onToday={goToToday}
            onOpenWalkthrough={onOpenWalkthroughAction}
            walkthroughLoading={walkthroughLoading}
          />

          <div className="w-full px-4 pt-4 lg:px-6">
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-xl border border-black/10 bg-white px-3 py-2">
                <div className="text-[10px] uppercase tracking-wide text-zinc-500">Week</div>
                <div className="mt-1 text-[13px] font-medium text-zinc-900">
                  {weekPhaseSummary ?? 'Current week'}
                </div>
              </div>

              <div className="rounded-xl border border-black/10 bg-white px-3 py-2">
                <div className="text-[10px] uppercase tracking-wide text-zinc-500">Today</div>
                <div className="mt-1 text-[13px] font-medium text-zinc-900">
                  {todaySummary ?? 'No workout scheduled today'}
                </div>
              </div>

              <div className="rounded-xl border border-black/10 bg-white px-3 py-2">
                <div className="text-[10px] uppercase tracking-wide text-zinc-500">Next</div>
                <div className="mt-1 text-[13px] font-medium text-zinc-900">
                  {nextSummary ?? 'No upcoming sessions yet'}
                </div>
              </div>
            </div>
          </div>

          <div className="w-full px-4 py-5 lg:px-6">
            {saveState !== 'idle' ? (
              <div
                className={`mb-3 rounded-lg border px-3 py-2 text-xs font-medium ${
                  saveState === 'error'
                    ? 'border-rose-200 bg-rose-50 text-rose-700'
                    : saveState === 'saving'
                      ? 'border-zinc-200 bg-white text-zinc-600'
                      : 'border-emerald-200 bg-emerald-50 text-emerald-700'
                }`}
              >
                {saveMessage}
              </div>
            ) : null}

            <div className="w-full overflow-x-auto">
              <DndContext sensors={sensors} onDragEnd={handleDragEnd}>
                <MonthGrid
                  currentMonth={currentMonth}
                  sessionsByDate={sessionsByDate}
                  completedSessions={completed}
                  stravaByDate={stravaByDate}
                  onSessionClick={(session) => setSelectedSession(session)}
                  onStravaActivityClick={(activity) => setSelectedActivity(activity)}
                />
              </DndContext>
            </div>
          </div>
        </div>
      )}

      {!isMobileView ? (
        <button
          type="button"
          onClick={() => setAddSessionDate(new Date())}
          className="fixed bottom-[calc(env(safe-area-inset-bottom)+16px)] right-4 z-30 inline-flex h-12 items-center justify-center rounded-full border border-black/10 bg-zinc-950 px-5 text-[14px] font-semibold text-white shadow-[0_14px_30px_rgba(0,0,0,0.25)] active:translate-y-[0.5px]"
          aria-label="Add session"
        >
          + Add session
        </button>
      ) : null}

      <SessionModal
        session={selectedSession}
        stravaActivity={selectedSession?.stravaActivity}
        open={!!selectedSession}
        onClose={() => setSelectedSession(null)}
        completedSessions={completed}
        onCompletedUpdate={(updatedList) => setCompleted(updatedList)}
        weekLabel={weekLabel}
        weekPhase={weekPhaseSummary ?? null}
        raceGoal={raceGoal ?? null}
        recentCompleted={recentExecution.recentCompleted}
        recentMissed={recentExecution.recentMissed}
        onSessionDeleted={handleSessionDeleted}
        onSessionUpdated={(updatedSession) => {
          setLocalSessions((prev) =>
            prev.map((session) =>
              String(session.id) === String(updatedSession.id)
                ? { ...session, details: updatedSession.details }
                : session
            )
          );

          setSelectedSession((prev) => {
            if (!prev) return null;

            if (String(prev.id) !== String(updatedSession.id)) {
              return prev;
            }

            return {
              ...prev,
              details: updatedSession.details,
            };
          });
        }}
      />

      <StravaActivityModal
        activity={selectedActivity}
        open={!!selectedActivity}
        onClose={() => setSelectedActivity(null)}
        timezone={timezone}
      />

      <AddSessionModalTP
        open={!!addSessionDate}
        date={addSessionDate ?? new Date()}
        onClose={() => setAddSessionDate(null)}
        onAdded={(newSession: MergedSession) => {
          handleSessionAdded(newSession);
          setAddSessionDate(null);
        }}
      />
    </main>
  );
}
