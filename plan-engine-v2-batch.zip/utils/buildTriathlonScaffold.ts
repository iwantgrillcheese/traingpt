import { addDays, formatISO, isValid, parseISO } from 'date-fns';
import type { UserParams, WeekJson, WeekMeta } from '@/types/plan';

type ScaffoldSport = 'swim' | 'bike' | 'run' | 'strength';

type ScaffoldSession = {
  sport: ScaffoldSport;
  title: string;
  details: string;
  durationMinutes: number;
  type:
    | 'swim_technique'
    | 'swim_endurance'
    | 'bike_endurance'
    | 'bike_quality'
    | 'long_ride'
    | 'run_easy'
    | 'run_quality'
    | 'long_run'
    | 'brick_run'
    | 'strength';
};

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] as const;

function isoDate(date: Date) {
  return formatISO(date, { representation: 'date' });
}

function dayNameToIndex(day?: string | null): number | null {
  if (!day) return null;
  const cleaned = day.trim().toLowerCase();
  const index = DAY_NAMES.findIndex((name) => name.toLowerCase() === cleaned);
  return index >= 0 ? index : null;
}

function dateForJsDay(weekStartISO: string, jsDay: number): string | null {
  const start = parseISO(weekStartISO);
  if (!isValid(start)) return null;

  // weekStartISO is expected to be Monday. JS day: Sunday = 0 ... Saturday = 6.
  const mondayBasedOffset = jsDay === 0 ? 6 : jsDay - 1;
  return isoDate(addDays(start, mondayBasedOffset));
}

function canonicalWeekDates(weekStartISO: string): string[] {
  const start = parseISO(weekStartISO);
  if (!isValid(start)) return [];
  return Array.from({ length: 7 }, (_, index) => isoDate(addDays(start, index)));
}

function isTriathlonRace(raceType: string) {
  return /tri|sprint|olympic|70\.3|half iron|ironman/i.test(raceType);
}

function raceFamily(raceType: string): 'sprint' | 'olympic' | 'half' | 'ironman' | 'triathlon' {
  const lower = raceType.toLowerCase();
  if (lower.includes('70.3') || lower.includes('half iron')) return 'half';
  if (lower.includes('ironman')) return 'ironman';
  if (lower.includes('olympic')) return 'olympic';
  if (lower.includes('sprint')) return 'sprint';
  return 'triathlon';
}


function cleanMetric(value: unknown): string | null {
  const text = String(value ?? '').replace(/\s+/g, ' ').trim();
  return text && text.toLowerCase() !== 'unknown' ? text : null;
}


function parsePaceToSeconds(value: unknown): number | null {
  const text = String(value ?? '').trim();
  if (!text) return null;
  const match = text.match(/(\d{1,2})\s*:\s*(\d{2})/);
  if (!match) return null;
  const minutes = Number(match[1]);
  const seconds = Number(match[2]);
  if (!Number.isFinite(minutes) || !Number.isFinite(seconds) || seconds >= 60) return null;
  return minutes * 60 + seconds;
}

function inferRunUnit(userParams: UserParams): 'mi' | 'km' {
  if (userParams.paceUnit === 'km') return 'km';
  if (userParams.paceUnit === 'mi') return 'mi';
  const text = String(userParams.runPace ?? '').toLowerCase();
  return text.includes('/km') || text.includes('per km') ? 'km' : 'mi';
}

function formatPace(seconds: number, unit: 'mi' | 'km'): string {
  const rounded = Math.max(1, Math.round(seconds));
  const minutes = Math.floor(rounded / 60);
  const secs = rounded % 60;
  return `${minutes}:${String(secs).padStart(2, '0')}/${unit}`;
}

function runPaceRange(userParams: UserParams, addLowSeconds: number, addHighSeconds: number): string | null {
  const thresholdSeconds = parsePaceToSeconds(userParams.runPace);
  if (!thresholdSeconds) return null;
  const unit = inferRunUnit(userParams);
  return `${formatPace(thresholdSeconds + addLowSeconds, unit)}-${formatPace(thresholdSeconds + addHighSeconds, unit)}`;
}

function runThresholdRange(userParams: UserParams): string | null {
  const thresholdSeconds = parsePaceToSeconds(userParams.runPace);
  if (!thresholdSeconds) return null;
  const unit = inferRunUnit(userParams);
  return `${formatPace(thresholdSeconds - 5, unit)}-${formatPace(thresholdSeconds + 10, unit)}`;
}

function easyRunRange(userParams: UserParams): string | null {
  // Long/easy running should usually be comfortably slower than threshold.
  // This range is intentionally conservative for triathlon durability.
  return runPaceRange(userParams, 75, 115);
}

function steadyRunRange(userParams: UserParams): string | null {
  return runPaceRange(userParams, 35, 65);
}

function ftpRange(ftp: unknown, low: number, high: number): string | null {
  const value = typeof ftp === 'number' && Number.isFinite(ftp) ? ftp : Number.parseFloat(String(ftp ?? ''));
  if (!Number.isFinite(value) || value <= 0) return null;
  return `${Math.round(value * low)}-${Math.round(value * high)}W (${Math.round(low * 100)}-${Math.round(high * 100)}% FTP)`;
}

function bikeMetricCue(userParams: UserParams, low: number, high: number, fallbackLabel: string): string {
  const range = ftpRange(userParams.bikeFtp, low, high);
  return range ? `Use your FTP to anchor the work: ${range}.` : fallbackLabel;
}

function runMetricCue(userParams: UserParams, label: string): string {
  const threshold = cleanMetric(userParams.runPace);
  return threshold ? `${label} Threshold reference: ${threshold}. Use effort first if heat, hills, or fatigue make pace unrealistic.` : label;
}

function longRunCue(userParams: UserParams, baseLabel: string, phase: ReturnType<typeof phaseIntensity>): string {
  const easyRange = easyRunRange(userParams);
  const steadyRange = steadyRunRange(userParams);

  if (!easyRange) return baseLabel;

  if (phase === 'peak' || phase === 'build') {
    return `${baseLabel} Target most of the run around ${easyRange}. If feeling controlled late, finish the final 10-20min closer to steady 70.3 effort (${steadyRange ?? 'controlled steady effort'}), not threshold.`;
  }

  if (phase === 'taper') {
    return `${baseLabel} Keep most of it around ${easyRange} or easier. No forced pace work.`;
  }

  return `${baseLabel} Target roughly ${easyRange}, staying conversational from start to finish.`;
}

function easyRunCue(userParams: UserParams, baseLabel: string): string {
  const easyRange = easyRunRange(userParams);
  return easyRange ? `${baseLabel} Keep it relaxed around ${easyRange}; this should feel clearly easier than threshold.` : baseLabel;
}

function thresholdRunCue(userParams: UserParams, baseLabel: string): string {
  const thresholdRange = runThresholdRange(userParams);
  return thresholdRange ? `${baseLabel} Aim for controlled reps around ${thresholdRange}; stop short of straining.` : runMetricCue(userParams, baseLabel);
}

function brickRunCue(userParams: UserParams, baseLabel: string, phase: ReturnType<typeof phaseIntensity>): string {
  const easyRange = easyRunRange(userParams);
  const steadyRange = steadyRunRange(userParams);
  if (!easyRange) return baseLabel;
  if (phase === 'peak' || phase === 'build') {
    return `${baseLabel} Start around ${easyRange}. Only let it progress toward ${steadyRange ?? 'steady race effort'} if the bike was controlled.`;
  }
  return `${baseLabel} Keep it easy around ${easyRange} or slower; the goal is transition rhythm, not pace.`;
}

function swimMetricCue(userParams: UserParams, label: string): string {
  const css = cleanMetric(userParams.swimPace);
  return css ? `${label} Use your swim threshold/CSS (${css}) as the anchor for controlled repeats, staying relaxed rather than forcing pace.` : label;
}

function phaseIntensity(phase: string, deload: boolean) {
  const lower = phase.toLowerCase();
  if (deload || lower.includes('recovery')) return 'recovery';
  if (lower.includes('taper')) return 'taper';
  if (lower.includes('peak')) return 'peak';
  if (lower.includes('build')) return 'build';
  return 'base';
}


type PhaseIntensity = ReturnType<typeof phaseIntensity>;
type DurationSessionType = ScaffoldSession['type'];

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, Math.round(value)));
}

function experienceModifier(experience: unknown): number {
  const text = String(experience ?? '').toLowerCase();
  if (text.includes('beginner') || text.includes('new')) return -0.08;
  if (text.includes('advanced') || text.includes('competitive')) return 0.08;
  return 0;
}

function weekLoadIndex(index: number, phase: PhaseIntensity): number {
  // Progress three weeks up, then pull back slightly on recovery/deload weeks.
  // We use the absolute index because total plan length is dynamic and phase is
  // already computed upstream. Caps inside each duration function prevent runaway growth.
  if (phase === 'recovery') return 0;
  if (phase === 'taper') return 0;
  return Math.max(0, index);
}

function maxHourModifier(maxHours: unknown): number {
  const hours = typeof maxHours === 'number' ? maxHours : Number.parseFloat(String(maxHours ?? ''));
  if (!Number.isFinite(hours) || hours <= 0) return 0;
  if (hours <= 5) return -0.16;
  if (hours <= 7) return -0.08;
  if (hours >= 12) return 0.08;
  if (hours >= 10) return 0.04;
  return 0;
}

function durationScale(userParams: UserParams): number {
  return clamp((1 + experienceModifier(userParams.experience) + maxHourModifier(userParams.maxHours)) * 100, 78, 112) / 100;
}

function minutesForSession(
  type: DurationSessionType,
  userParams: UserParams,
  weekMeta: WeekMeta,
  index: number
): number {
  const family = raceFamily(userParams.raceType);
  const phase = phaseIntensity(weekMeta.phase, weekMeta.deload);
  const loadIndex = weekLoadIndex(index, phase);
  const scale = durationScale(userParams);

  const scaled = (minutes: number, min: number, max: number) => clamp(minutes * scale, min, max);

  if (type === 'strength') {
    if (phase === 'taper' || phase === 'recovery') return 20;
    return 30;
  }

  if (type === 'brick_run') {
    if (phase === 'taper') return 10;
    if (phase === 'recovery') return 10;
    if (family === 'sprint') return scaled(8 + Math.min(loadIndex, 8), 8, 15);
    if (family === 'olympic') return scaled(10 + Math.min(loadIndex, 10), 10, 22);
    if (family === 'ironman') return scaled(12 + Math.min(loadIndex, 16), 10, 28);
    return scaled(12 + Math.min(loadIndex, 16), 10, 30);
  }

  if (type === 'long_ride') {
    if (phase === 'taper') return family === 'sprint' || family === 'olympic' ? 45 : 60;
    if (phase === 'recovery') return family === 'ironman' ? 120 : family === 'half' ? 90 : 60;

    if (family === 'sprint') return scaled(45 + loadIndex * 4, 40, 75);
    if (family === 'olympic') return scaled(65 + loadIndex * 5, 60, 110);
    if (family === 'ironman') {
      if (phase === 'peak') return scaled(210 + Math.min(loadIndex, 4) * 10, 180, 300);
      if (phase === 'build') return scaled(150 + Math.min(loadIndex, 10) * 9, 130, 240);
      return scaled(110 + Math.min(loadIndex, 8) * 8, 90, 165);
    }
    // 70.3 / default long-course progression
    if (phase === 'peak') return scaled(180 + Math.min(loadIndex, 4) * 8, 165, 210);
    if (phase === 'build') return scaled(135 + Math.min(loadIndex, 10) * 7, 120, 185);
    return scaled(90 + Math.min(loadIndex, 7) * 7, 75, 140);
  }

  if (type === 'long_run') {
    if (phase === 'taper') return family === 'sprint' || family === 'olympic' ? 30 : 45;
    if (phase === 'recovery') return family === 'ironman' ? 70 : family === 'half' ? 50 : 35;

    if (family === 'sprint') return scaled(30 + loadIndex * 3, 25, 55);
    if (family === 'olympic') return scaled(40 + loadIndex * 4, 35, 75);
    if (family === 'ironman') {
      if (phase === 'peak') return scaled(110 + Math.min(loadIndex, 4) * 5, 95, 135);
      if (phase === 'build') return scaled(80 + Math.min(loadIndex, 10) * 4, 70, 115);
      return scaled(55 + Math.min(loadIndex, 7) * 4, 45, 85);
    }
    if (phase === 'peak') return scaled(90 + Math.min(loadIndex, 4) * 4, 80, 105);
    if (phase === 'build') return scaled(70 + Math.min(loadIndex, 10) * 3, 60, 95);
    return scaled(50 + Math.min(loadIndex, 7) * 4, 40, 75);
  }

  if (type === 'bike_quality') {
    if (phase === 'taper' || phase === 'recovery') return 45;
    if (family === 'ironman') return scaled(65 + Math.min(loadIndex, 6) * 3, 55, 90);
    if (family === 'half') return scaled(60 + Math.min(loadIndex, 6) * 3, 50, 80);
    return scaled(45 + Math.min(loadIndex, 5) * 3, 35, 65);
  }

  if (type === 'bike_endurance') {
    if (phase === 'taper' || phase === 'recovery') return 40;
    if (family === 'ironman') return scaled(60 + Math.min(loadIndex, 6) * 3, 45, 85);
    if (family === 'half') return scaled(50 + Math.min(loadIndex, 6) * 2, 40, 70);
    return scaled(40 + Math.min(loadIndex, 5) * 2, 30, 55);
  }

  if (type === 'run_quality') {
    if (phase === 'taper' || phase === 'recovery') return 35;
    if (family === 'ironman') return scaled(45 + Math.min(loadIndex, 5) * 2, 40, 60);
    if (family === 'half') return scaled(45 + Math.min(loadIndex, 5) * 2, 35, 60);
    return scaled(35 + Math.min(loadIndex, 4) * 2, 30, 50);
  }

  if (type === 'run_easy') {
    if (phase === 'taper' || phase === 'recovery') return 30;
    return scaled(35 + Math.min(loadIndex, 4) * 2, 25, 50);
  }

  if (type === 'swim_technique') {
    if (phase === 'taper' || phase === 'recovery') return 35;
    return scaled(40 + Math.min(loadIndex, 4) * 2, 30, 55);
  }

  if (type === 'swim_endurance') {
    if (phase === 'taper' || phase === 'recovery') return 35;
    if (family === 'ironman') return scaled(50 + Math.min(loadIndex, 6) * 2, 40, 70);
    if (family === 'half') return scaled(45 + Math.min(loadIndex, 6) * 2, 35, 65);
    return scaled(35 + Math.min(loadIndex, 5) * 2, 30, 50);
  }

  return 45;
}

function formatDuration(minutes: number): string {
  const rounded = Math.max(1, Math.round(minutes));
  if (rounded < 60) return `${rounded}min`;
  const hours = Math.floor(rounded / 60);
  const remainder = rounded % 60;
  return remainder ? `${hours}h ${remainder}min` : `${hours}h`;
}

function hasDurationText(details: string): boolean {
  return /\b\d+\s*(?:min|mins|minutes|m)\b|\b\d+(?:\.\d+)?\s*h(?:r|rs|our|ours)?\b/i.test(details);
}

function withDuration(minutes: number, details: string): string {
  const clean = details.replace(/\s+/g, ' ').trim();
  if (!clean) return formatDuration(minutes);
  return hasDurationText(clean) ? clean : `${formatDuration(minutes)}. ${clean}`;
}

function makeSession(
  type: DurationSessionType,
  sport: ScaffoldSport,
  title: string,
  rawDetails: string,
  userParams: UserParams,
  weekMeta: WeekMeta,
  index: number
): ScaffoldSession {
  const durationMinutes = minutesForSession(type, userParams, weekMeta, index);
  return {
    sport,
    title,
    type,
    durationMinutes,
    details: withDuration(durationMinutes, rawDetails),
  };
}

function getLongRideDetails(userParams: UserParams, weekMeta: WeekMeta) {
  const family = raceFamily(userParams.raceType);
  const phase = phaseIntensity(weekMeta.phase, weekMeta.deload);

  if (phase === 'taper') {
    return `Reduced aerobic long ride. Stay mostly Z2, include a few short relaxed race-effort pickups if fresh, and finish feeling sharp. ${bikeMetricCue(userParams, 0.62, 0.72, 'Keep the effort clearly aerobic.')}`;
  }

  if (family === 'half') {
    return `Aerobic long ride for 70.3 durability. Practice fueling every 20-30min and finish controlled rather than depleted. ${bikeMetricCue(userParams, 0.65, 0.75, 'Keep most of the ride in Z2 / conversational endurance effort.')}`;
  }

  if (family === 'ironman') {
    return `Long aerobic ride focused on steady pacing, fueling practice, and staying relaxed. ${bikeMetricCue(userParams, 0.63, 0.72, 'Keep the effort sustainable from start to finish.')}`;
  }

  if (family === 'sprint' || family === 'olympic') {
    return `Aerobic endurance ride with a few controlled race-effort segments. Keep the final 10min smooth and confident. ${bikeMetricCue(userParams, 0.7, 0.85, 'Use controlled race-effort, not all-out intensity.')}`;
  }

  return `Aerobic long ride focused on durability, fueling, and controlled pacing. ${bikeMetricCue(userParams, 0.65, 0.75, 'Keep effort controlled and aerobic.')}`;
}

function getBrickRunDetails(userParams: UserParams, weekMeta: WeekMeta) {
  const phase = phaseIntensity(weekMeta.phase, weekMeta.deload);
  if (phase === 'taper') return brickRunCue(userParams, '10-15min very easy off the bike. Keep cadence quick, shoulders relaxed, and effort light.', phase);
  if (phase === 'base') return brickRunCue(userParams, '10-15min easy off the bike. Focus on quick cadence and relaxed form.', phase);
  if (phase === 'peak') return brickRunCue(userParams, '20-30min controlled off the bike. Start easy, then settle into realistic race effort only if fresh.', phase);
  return brickRunCue(userParams, '15-25min easy-to-steady off the bike. Practice transition rhythm, posture, and controlled pacing.', phase);
}

function getLongRunDetails(userParams: UserParams, weekMeta: WeekMeta) {
  const phase = phaseIntensity(weekMeta.phase, weekMeta.deload);
  if (phase === 'taper') return longRunCue(userParams, 'Reduced long run. Keep it easy and relaxed with no forced pace work.', phase);
  if (phase === 'peak') return longRunCue(userParams, 'Long aerobic run with controlled pacing. Keep effort sustainable and avoid turning it into a race.', phase);
  return longRunCue(userParams, 'Long easy aerobic run. Stay conversational and build durability without excess fatigue.', phase);
}

function getRunQualityDetails(userParams: UserParams, weekMeta: WeekMeta) {
  const phase = phaseIntensity(weekMeta.phase, weekMeta.deload);
  if (phase === 'recovery' || phase === 'taper') return easyRunCue(userParams, 'Easy aerobic run with 4-6 relaxed strides if fresh. Keep the session light.');
  if (phase === 'base') return easyRunCue(userParams, 'Controlled aerobic run with short strides. Build rhythm without heavy intensity.');
  return thresholdRunCue(userParams, 'Threshold-focused run. Include a steady main set at controlled threshold effort with easy recoveries.');
}

function getBikeMidweekDetails(userParams: UserParams, weekMeta: WeekMeta) {
  const phase = phaseIntensity(weekMeta.phase, weekMeta.deload);
  if (phase === 'recovery' || phase === 'taper') return `Easy aerobic spin. Keep cadence smooth and effort relaxed. ${bikeMetricCue(userParams, 0.55, 0.68, 'Stay very comfortable.')}`;
  if (phase === 'base') return `Aerobic bike with steady Z2 work. Keep effort controlled and build consistency. ${bikeMetricCue(userParams, 0.65, 0.75, 'Stay aerobic throughout.')}`;
  return `Bike strength or tempo session. Include controlled steady intervals while keeping the weekend endurance ride protected. ${bikeMetricCue(userParams, 0.82, 0.9, 'Keep tempo controlled, not maximal.')}`;
}

function getSwimDetails(kind: 'Technique' | 'Endurance', userParams: UserParams, weekMeta: WeekMeta) {
  const comfort = String(userParams.swimComfort ?? '').toLowerCase();

  if (kind === 'Technique' || comfort === 'new' || comfort === 'developing') {
    return swimMetricCue(userParams, 'Technique-focused swim. Include easy warmup, drill work, short relaxed repeats, and smooth cooldown. Prioritize body position, breathing, and comfort.');
  }

  return swimMetricCue(userParams, 'Endurance swim. Include easy warmup, steady aerobic repeats, and cooldown. Keep pacing smooth and sustainable rather than forcing speed.');
}

function findAvailableDay(preferred: number, blocked: Set<number>, used: Set<number>, allowUsed = false): number {
  if (!blocked.has(preferred) && (allowUsed || !used.has(preferred))) return preferred;

  const priority = [2, 3, 4, 5, 1, 6, 0]; // Tue, Wed, Thu, Fri, Mon, Sat, Sun
  return priority.find((day) => !blocked.has(day) && (allowUsed || !used.has(day))) ?? preferred;
}

function addSession(
  days: Record<string, ScaffoldSession[]>,
  weekStartISO: string,
  jsDay: number,
  session: ScaffoldSession
) {
  const date = dateForJsDay(weekStartISO, jsDay);
  if (!date) return;
  days[date] = [...(days[date] ?? []), session];
}

function sessionKey(session: unknown) {
  if (!session || typeof session !== 'object' || Array.isArray(session)) return '';
  const record = session as Record<string, unknown>;
  return `${String(record.sport ?? '').toLowerCase()} ${String(record.title ?? '').toLowerCase()} ${String(record.details ?? '').toLowerCase()}`;
}

function usefulGeneratedDetails(session: unknown): string | null {
  if (!session || typeof session !== 'object' || Array.isArray(session)) return null;
  const record = session as Record<string, unknown>;
  const details = String(record.details ?? record.description ?? '').replace(/\s+/g, ' ').trim();
  if (!details || /^details$/i.test(details) || /^tbd$/i.test(details)) return null;
  if (details.length < 20) return null;
  return details;
}

function flattenGeneratedSessions(week: WeekJson): unknown[] {
  const days = week?.days && typeof week.days === 'object' && !Array.isArray(week.days) ? week.days : {};
  return Object.values(days).flatMap((items) => (Array.isArray(items) ? items : []));
}

function isMatchingGeneratedSession(slot: ScaffoldSession, generated: unknown) {
  const key = sessionKey(generated);
  if (!key) return false;
  const sport = slot.sport.toLowerCase();
  const title = slot.title.toLowerCase();

  if (!key.includes(sport)) return false;

  if (title.includes('long ride')) return /long ride|endurance ride|bike endurance/.test(key);
  if (title.includes('brick run')) return /brick run|off the bike|transition run/.test(key);
  if (title.includes('long run')) return /long run/.test(key);
  if (title.includes('threshold')) return /threshold|tempo|interval/.test(key);
  if (title.includes('technique')) return /technique|drill/.test(key);
  if (title.includes('endurance')) return /endurance|aerobic|steady/.test(key);

  return key.includes(title);
}

export function buildTriathlonWeekScaffold({
  userParams,
  weekMeta,
  index = 0,
}: {
  userParams: UserParams;
  weekMeta: WeekMeta;
  index?: number;
}): WeekJson | null {
  if (!isTriathlonRace(userParams.raceType)) return null;

  const weekDates = canonicalWeekDates(weekMeta.startDate);
  const days: Record<string, ScaffoldSession[]> = Object.fromEntries(weekDates.map((date) => [date, []]));

  const prefs = userParams.trainingPrefs ?? {};
  const restDay = dayNameToIndex(userParams.restDay) ?? 1;
  const longRideDay = prefs.longRideDay ?? dayNameToIndex(userParams.preferredLongRideDay) ?? 6;
  const longRunDay = prefs.longRunDay ?? dayNameToIndex(userParams.preferredLongRunDay) ?? 0;
  const unavailable = new Set((userParams.unavailableDays ?? []).map(dayNameToIndex).filter((v): v is number => v !== null));
  const blocked = new Set<number>([restDay, ...Array.from(unavailable)]);

  const used = new Set<number>();
  const phase = phaseIntensity(weekMeta.phase, weekMeta.deload);
  const isRaceWeek = Boolean(userParams.raceDate && weekDates.includes(userParams.raceDate));

  // Race week should be light and confidence-building. Do not force normal
  // long ride / brick / long run structure into race week.
  if (isRaceWeek) {
    const easySwimDay = findAvailableDay(2, blocked, used); // Tue
    addSession(days, weekMeta.startDate, easySwimDay, makeSession(
      'swim_technique',
      'swim',
      'Swim Easy',
      'Short relaxed swim with a few smooth pickups. Keep effort easy and focus on feeling comfortable in the water.',
      userParams,
      weekMeta,
      index
    ));
    used.add(easySwimDay);

    const easyBikeDay = findAvailableDay(3, blocked, used); // Wed
    addSession(days, weekMeta.startDate, easyBikeDay, makeSession(
      'bike_endurance',
      'bike',
      'Bike Easy',
      'Short aerobic spin with a few light cadence pickups. Keep the legs fresh and avoid fatigue.',
      userParams,
      weekMeta,
      index
    ));
    used.add(easyBikeDay);

    const easyRunDay = findAvailableDay(4, blocked, used); // Thu
    addSession(days, weekMeta.startDate, easyRunDay, makeSession(
      'run_easy',
      'run',
      'Run Easy',
      'Short easy run with relaxed strides if fresh. Finish feeling better than you started.',
      userParams,
      weekMeta,
      index
    ));

    return {
      label: weekMeta.label,
      phase: weekMeta.phase,
      startDate: weekMeta.startDate,
      deload: weekMeta.deload,
      days,
    } as WeekJson;
  }

  // Key sessions. These are non-negotiable structure slots.
  const safeLongRideDay = findAvailableDay(longRideDay, blocked, used, true);
  addSession(days, weekMeta.startDate, safeLongRideDay, makeSession(
    'long_ride',
    'bike',
    'Long Ride',
    getLongRideDetails(userParams, weekMeta),
    userParams,
    weekMeta,
    index
  ));
  used.add(safeLongRideDay);

  // Every non-race triathlon week gets brick practice appropriate to phase/race.
  {
    addSession(days, weekMeta.startDate, safeLongRideDay, makeSession(
      'brick_run',
      'run',
      'Brick Run',
      getBrickRunDetails(userParams, weekMeta),
      userParams,
      weekMeta,
      index
    ));
  }

  const safeLongRunDay = findAvailableDay(longRunDay, blocked, used, true);
  addSession(days, weekMeta.startDate, safeLongRunDay, makeSession(
    phase === 'taper' ? 'run_easy' : 'long_run',
    'run',
    phase === 'taper' ? 'Run Easy' : 'Long Run',
    getLongRunDetails(userParams, weekMeta),
    userParams,
    weekMeta,
    index
  ));
  used.add(safeLongRunDay);

  // Supporting sessions.
  const swimTechniqueDay = findAvailableDay(2, blocked, used); // Tue
  addSession(days, weekMeta.startDate, swimTechniqueDay, makeSession(
    'swim_technique',
    'swim',
    'Swim Technique',
    getSwimDetails('Technique', userParams, weekMeta),
    userParams,
    weekMeta,
    index
  ));
  used.add(swimTechniqueDay);

  const bikeDay = findAvailableDay(4, blocked, used); // Thu
  addSession(days, weekMeta.startDate, bikeDay, makeSession(
    phase === 'build' || phase === 'peak' ? 'bike_quality' : 'bike_endurance',
    'bike',
    phase === 'build' || phase === 'peak' ? 'Bike Threshold' : 'Bike Endurance',
    getBikeMidweekDetails(userParams, weekMeta),
    userParams,
    weekMeta,
    index
  ));
  used.add(bikeDay);

  const swimEnduranceDay = findAvailableDay(5, blocked, used); // Fri
  addSession(days, weekMeta.startDate, swimEnduranceDay, makeSession(
    'swim_endurance',
    'swim',
    'Swim Endurance',
    getSwimDetails('Endurance', userParams, weekMeta),
    userParams,
    weekMeta,
    index
  ));
  used.add(swimEnduranceDay);

  const runQualityDay = findAvailableDay(3, blocked, used); // Wed
  addSession(days, weekMeta.startDate, runQualityDay, makeSession(
    phase === 'build' || phase === 'peak' ? 'run_quality' : 'run_easy',
    'run',
    phase === 'build' || phase === 'peak' ? 'Run Threshold' : 'Run Easy',
    getRunQualityDetails(userParams, weekMeta),
    userParams,
    weekMeta,
    index
  ));
  used.add(runQualityDay);

  // Optional strength. Keep secondary and never duplicate.
  const notes = `${userParams.athleteNotes ?? ''} ${(userParams.coachingPriorities ?? []).join(' ')}`.toLowerCase();
  const wantsStrength = /strength|lift|gym|weights/.test(notes);
  if (wantsStrength || String(userParams.experience).toLowerCase().includes('advanced')) {
    const strengthDay = findAvailableDay(3, blocked, new Set([safeLongRideDay, safeLongRunDay]), true);
    addSession(days, weekMeta.startDate, strengthDay, makeSession(
      'strength',
      'strength',
      'Strength',
      'Short general strength session for durability. Keep it controlled, avoid heavy fatigue, and keep triathlon sessions as the priority.',
      userParams,
      weekMeta,
      index
    ));
  }

  return {
    label: weekMeta.label,
    phase: weekMeta.phase,
    startDate: weekMeta.startDate,
    deload: weekMeta.deload,
    days,
  } as WeekJson;
}

export function scaffoldSummary(scaffold: WeekJson | null): string {
  if (!scaffold) return 'No deterministic scaffold provided.';
  return JSON.stringify(scaffold.days, null, 2);
}

export function applyTriathlonScaffold({
  generatedWeek,
  scaffold,
}: {
  generatedWeek: WeekJson;
  scaffold: WeekJson | null;
}): WeekJson {
  if (!scaffold) return generatedWeek;

  const generatedSessions = flattenGeneratedSessions(generatedWeek);
  const days: Record<string, ScaffoldSession[]> = {};

  for (const [date, scaffoldItems] of Object.entries(scaffold.days)) {
    const slots = (Array.isArray(scaffoldItems) ? scaffoldItems : []) as ScaffoldSession[];

    days[date] = slots.map((slot) => {
      const generatedMatch = generatedSessions.find((candidate) => isMatchingGeneratedSession(slot, candidate));
      const generatedDetails = usefulGeneratedDetails(generatedMatch);

      const details = generatedDetails ?? slot.details;

      return {
        ...slot,
        details: withDuration(slot.durationMinutes, details),
      };
    });
  }

  return {
    ...generatedWeek,
    label: scaffold.label,
    phase: scaffold.phase,
    startDate: scaffold.startDate,
    deload: scaffold.deload,
    days,
    debug: [
      generatedWeek.debug,
      'Applied deterministic triathlon scaffold. GPT was used for workout detail enrichment, not weekly structure.',
    ]
      .filter(Boolean)
      .join('\n'),
  } as WeekJson;
}
