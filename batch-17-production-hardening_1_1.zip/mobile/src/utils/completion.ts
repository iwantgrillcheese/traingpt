// mobile/src/utils/completion.ts
//
// Server-authoritative workout completion for the Expo app. Replaces the
// direct `completed_sessions` delete+insert writes that used to live in
// TodayScreen / ScheduleScreen / ProgressScreen — those bypassed the server's
// ownership, future-date, and idempotency checks.

import { apiFetch } from '../lib/api';

export type CompletionMode = 'done' | 'skipped';

export async function setSessionCompletion({
  sessionId,
  mode,
  undo = false,
}: {
  sessionId: string;
  mode: CompletionMode;
  undo?: boolean;
}): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await apiFetch(mode === 'done' ? '/api/schedule/mark-done' : '/api/schedule/mark-skip', {
      method: 'POST',
      body: JSON.stringify({ sessionId, undo }),
    });

    const json = await res.json().catch(() => null);

    if (!res.ok) {
      return { ok: false, error: (json && json.error) || 'Could not update session status.' };
    }

    return { ok: true };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : 'Network error.' };
  }
}
