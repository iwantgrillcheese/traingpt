// /mobile/src/utils/enrichPlan.ts
//
// Background enrichment loop for scaffold-first plans, now resumable: if the
// app was closed mid-run, `resumeEnrichmentIfPending` picks up from the first
// missing week the next time a screen loads. The plan is fully usable
// throughout (scaffold details are complete); failed weeks keep their
// scaffold details.
//
// Guarantees mirrored from the web runner:
//   * res.ok is checked; failures are never treated as success.
//   * Already-enriched weeks are skipped (server is idempotent as well).
//   * Bounded retries with backoff for transient failures.
//   * One loop per plan; a newer plan generation supersedes a running loop.

import { apiFetch } from '../lib/api';
import { supabase } from '../lib/supabase';

let activeFor: string | null = null;

const MAX_RETRIES_PER_WEEK = 2;
const RETRY_BACKOFF_MS = [1000, 3000];

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

type WeekResult = 'enriched' | 'already' | 'failed' | 'conflict' | 'superseded';

async function enrichOneWeek(planId: string, weekIndex: number, userId: string): Promise<WeekResult> {
  for (let attempt = 0; attempt <= MAX_RETRIES_PER_WEEK; attempt++) {
    if (activeFor !== planId) return 'superseded';

    try {
      const res = await apiFetch('/api/enrich-week', {
        method: 'POST',
        body: JSON.stringify({ planId, weekIndex, clientUserId: userId }),
      });

      const json = await res.json().catch(() => null);

      if (res.status === 409) return 'conflict';
      if (res.status === 429) {
        console.warn('[enrichPlan] rate limited; pausing', { planId, weekIndex });
        return 'failed';
      }

      if (!res.ok || (json && json.ok !== true) || (json && json.failed === true)) {
        if (attempt < MAX_RETRIES_PER_WEEK) {
          await sleep(RETRY_BACKOFF_MS[attempt] ?? 3000);
          continue;
        }
        return 'failed';
      }

      if (json && json.alreadyEnriched === true) return 'already';
      return 'enriched';
    } catch (error) {
      console.error('[enrichPlan] week request failed', { planId, weekIndex, attempt, error });
      if (attempt < MAX_RETRIES_PER_WEEK) {
        await sleep(RETRY_BACKOFF_MS[attempt] ?? 3000);
        continue;
      }
      return 'failed';
    }
  }
  return 'failed';
}

async function runLoop({
  planId,
  totalWeeks,
  userId,
  skipWeeks,
}: {
  planId: string;
  totalWeeks: number;
  userId: string;
  skipWeeks: Set<number>;
}) {
  let failures = 0;

  for (let weekIndex = 0; weekIndex < totalWeeks; weekIndex++) {
    if (activeFor !== planId) return; // superseded by a newer plan
    if (skipWeeks.has(weekIndex)) continue;

    const result = await enrichOneWeek(planId, weekIndex, userId);
    if (result === 'superseded' || result === 'conflict') return;
    if (result === 'failed') {
      failures += 1;
      if (failures >= 3) {
        console.warn('[enrichPlan] too many failures; pausing until next resume', { planId });
        return;
      }
    }
  }
}

export async function enrichPlanInBackground({
  planId,
  totalWeeks,
  userId,
}: {
  planId: string;
  totalWeeks: number;
  userId: string;
}): Promise<void> {
  if (!planId || !Number.isFinite(totalWeeks) || totalWeeks <= 0 || !userId) return;
  if (activeFor === planId) return;

  activeFor = planId;
  try {
    await runLoop({ planId, totalWeeks, userId, skipWeeks: new Set() });
  } finally {
    if (activeFor === planId) activeFor = null;
  }
}

/**
 * Resume a partially enriched plan (metadata.enrichment.pending === true).
 * Safe to call on screen load / app resume: no-ops when there is nothing to
 * do or a loop is already running.
 */
export async function resumeEnrichmentIfPending(userId: string | undefined | null): Promise<void> {
  if (!userId || activeFor !== null) return;

  try {
    const { data: planRow, error } = await supabase
      .from('plans')
      .select('id, plan')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !planRow?.plan) return;

    const plan = planRow.plan as any;
    if (plan?.planType !== 'triathlon') return;

    const enrichment = plan?.metadata?.enrichment;
    if (!enrichment || enrichment.pending !== true) return;

    const totalWeeks = Array.isArray(plan?.weeks) ? plan.weeks.length : 0;
    if (totalWeeks <= 0) return;

    const enrichedWeeks: number[] = Array.isArray(enrichment.enrichedWeeks) ? enrichment.enrichedWeeks : [];
    const skipWeeks = new Set<number>(enrichedWeeks);
    if (skipWeeks.size >= totalWeeks) return;

    const planId = String(planRow.id);
    if (activeFor !== null) return;
    activeFor = planId;

    try {
      await runLoop({ planId, totalWeeks, userId, skipWeeks });
    } finally {
      if (activeFor === planId) activeFor = null;
    }
  } catch (error) {
    console.error('[enrichPlan] resume check failed', error);
  }
}
