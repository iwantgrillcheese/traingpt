# Production Hardening — July 2026 Sprint

This document covers the security/data-integrity changes shipped in this
sprint: what changed, the exact migration and deployment steps, and the
environment variables production must have.

## What changed (summary)

**P0 — privileged endpoint abuse**
- All four cron routes (`adapt-week`, `send-email/daily-session`,
  `send-email/upcoming-week`, `training-review`) now use one shared,
  fail-closed authorizer (`lib/server/cronAuth.ts`). In production a missing
  `CRON_SECRET` rejects every request (503) and logs a configuration error;
  only `Authorization: Bearer <CRON_SECRET>` is accepted; query-param secrets
  are dev-only behind `ALLOW_INSECURE_CRON=true`.
- The legacy welcome-email chain was removed
  (`app/api/send-email/welcome`, `app/api/send-welcome-email`,
  `lib/emails/send-welcome-email.ts`, `generateWelcomeEmail.tsx`,
  `WelcomeEmail.tsx`). The first was an unauthenticated open relay that could
  send to arbitrary addresses via the TrainGPT Resend account. The active,
  authenticated signup email (`app/api/send-email/signup`) is unchanged.
- Account deletion is now a server-side route (`POST /api/account/delete`,
  body `{"confirm":"DELETE"}`) that deletes all TrainGPT data in a safe
  order, deletes the Supabase Auth user last, and reports partial failures
  without claiming success. The browser never touches the service-role key.

**P0 — atomic plan replacement**
- `POST /api/finalize-plan` persists through a new Postgres function
  `replace_plan_atomic` (migration `20260710121000`): one transaction, only
  the superseded generated plan's sessions are replaced, manual sessions are
  preserved, and duplicate submissions (same `clientRequestId`) replay
  idempotently. The repaired plan is re-validated before persistence.
  If the migration has not been applied yet, a degraded fallback is used that
  still never deletes manual sessions (loudly logged).

**P0 — server-authoritative completion**
- `mark-done` / `mark-skip` accept `sessionId`, verify ownership server-side,
  reject future dates (America/Los_Angeles fallback timezone), and write via
  an atomic upsert on `completed_sessions.session_id` (new column + FK +
  unique index, with an unambiguous-match backfill). Undo is idempotent.
  Legacy `date+title` callers still work when the pair is unambiguous (409
  otherwise). All Expo screens now call these routes instead of writing to
  `completed_sessions` directly.

**P1 — bounded AI usage / resumable enrichment**
- Server-side request validation for plan generation (race types, race date
  after today, ≤ `MAX_PLAN_WEEKS` (default 52), `maxHours` 1–30, FTP/pace
  bounds, note/array caps). Invalid input → 400 with details.
- Durable Supabase-backed per-user limiter (`api_usage_events` table) on
  `/api/finalize-plan`, `/api/enrich-week`, `/api/generate-detailed-session`,
  `/api/strava/analyze`, `/api/coach-chat`. Over-limit → 429 + Retry-After.
- Enrichment is idempotent per week server-side, resumable client-side
  (web: on schedule load; mobile: on Today screen load), retries transient
  failures with backoff, never treats a failed response as success, and uses
  optimistic concurrency (`plans.updated_at`) so stale tabs cannot overwrite
  newer plan JSON.

**P1 — Strava OAuth state**
- One signed, expiring state implementation for web AND mobile
  (`lib/server/stravaState.ts`); web state is bound to the authenticated user
  and verified against the session in the callback. Unsigned/expired/tampered
  state is rejected before any token exchange. The production signing secret
  must be explicit (`STRAVA_STATE_SECRET`); there is no dev-constant fallback
  in production.
- New `POST /api/strava/connect` (web) and `GET /api/strava/status`.
  Client components no longer SELECT `strava_access_token` to check
  connection status.

## Migrations (run BEFORE deploying the new code)

Both migrations are additive and safe to run on the live database.

```bash
# from the repo root, with the Supabase CLI linked to the project:
supabase db push
# or apply manually in order:
#   supabase/migrations/20260710120000_security_hardening.sql
#   supabase/migrations/20260710121000_replace_plan_atomic.sql
```

Verified locally against PostgreSQL 16: both migrations run cleanly on an
empty database and on a seeded one, and the completed_sessions backfill links
only rows with exactly one matching session.

An integration test for the plan-replacement function is included:

```bash
createdb traingpt_test
psql -v ON_ERROR_STOP=1 -d traingpt_test -f tests/sql/replace_plan_atomic.test.sql
```

## Deployment steps

1. Apply the two migrations (above).
2. Set/verify the production environment variables (below) in Vercel.
3. Deploy the web app (`main` → Vercel). `yarn verify` (lint + typecheck +
   unit tests + production build) must pass; CI runs it on every push/PR.
4. Ship a new mobile build (EAS) — completion writes and Strava connect on
   iOS now go through the API. Old mobile builds keep working: completion
   routes accept the legacy date+title identity, and the mobile OAuth state
   format is unchanged.
5. Smoke-test: generate a plan, add a manual session, regenerate the plan and
   confirm the manual session survives; mark a workout done/undone; connect
   Strava on web; hit a cron route without the bearer header and confirm 401.

## Required production environment variables (values not shown)

Already required, unchanged:
- `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`
- `OPENAI_API_KEY`
- `STRAVA_CLIENT_ID`, `STRAVA_CLIENT_SECRET`
- `RESEND_API_KEY`
- `NEXT_PUBLIC_BASE_URL`

Now enforced (deploys will reject the relevant flows without them):
- `CRON_SECRET` — cron routes fail closed without it. Vercel automatically
  sends it as `Authorization: Bearer <CRON_SECRET>` for `vercel.json` crons.
- `STRAVA_STATE_SECRET` — signs OAuth state (falls back to
  `NEXTAUTH_SECRET` if set; production refuses to run the Strava flows with
  neither).

Optional tuning:
- `MAX_PLAN_WEEKS` (default 52)
- `RATE_LIMIT_<ROUTE>__LIMIT` / `RATE_LIMIT_<ROUTE>__WINDOW_SECONDS`
  (e.g. `RATE_LIMIT_API_FINALIZE_PLAN__LIMIT=6`)
- `DAILY_EMAIL_TIMEZONE` (default `America/Los_Angeles`)
- `ALLOW_INSECURE_CRON=true` — local development only; never set in prod.

## Testing

- `yarn test` — 40 unit tests (cron auth, Strava state, plan-request
  validation, completion ownership/future-date/idempotency/undo, rate limiter).
- `yarn verify` — lint + typecheck + tests + production build.
- `cd mobile && npm run typecheck` — mobile typecheck (tsconfig fixed).
- `tests/sql/replace_plan_atomic.test.sql` — DB-level replacement guarantees.
