// /lib/enrichmentRunner.ts
//
// Client-side runner that progressively enriches a scaffold-first triathlon
// plan, and — new — RESUMES enrichment for plans whose
// metadata.enrichment.pending is still true (e.g. the user closed the tab
// mid-run after generation).
//
// Guarantees:
//   * res.ok is checked; a failed response is never broadcast as success.
//   * Weeks already marked enriched are skipped (the server is idempotent
//     too, so duplicate loops cannot double-spend LLM calls).
//   * Bounded retries with backoff for transient (network / 5xx) failures.
//   * Only one loop per plan per tab (activeRunFor guard); a newer plan
//     generation supersedes any running loop.
//   * A 409 from the server means the plan changed underneath us — the loop
//     stops instead of overwriting newer plan JSON with stale data.
//
// Progress is broadcast as window CustomEvents:
//   window.addEventListener('traingpt:week-enriched', (e) => { ... })
//   window.addEventListener('traingpt:enrichment-complete', (e) => { ... })

'use client';

import { supabase } from '@/lib/supabase/client';

export type EnrichmentProgressDetail = {
  planId: string;
  weekIndex: number;
  totalWeeks: number;
  enrichedCount: number;
};

const MAX_RETRIES_PER_WEEK = 2;
const RETRY_BACKOFF_MS = [1000, 3000];

let activeRunFor: string | null = null;

function broadcast(name: string, detail: Record<string, unknown>) {
  if (typeof window === 'undefined') return;
  try {
    window.dispatchEvent(new CustomEvent(name, { detail }));
  } catch {
    // Non-fatal: progress UI is optional.
  }
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function isEnrichmentRunning(planId?: string) {
  return planId ? activeRunFor === planId : activeRunFor !== null;
}

type WeekResult = 'enriched' | 'already' | 'failed' | 'conflict' | 'superseded';

async function enrichOneWeek({
  planId,
  weekIndex,
  userId,
  totalWeeks,
}: {
  planId: string;
  weekIndex: number;
  userId: string;
  totalWeeks: number;
}): Promise<WeekResult> {
  for (let attempt = 0; attempt <= MAX_RETRIES_PER_WEEK; attempt++) {
    if (activeRunFor !== planId) return 'superseded';

    try {
      const res = await fetch('/api/enrich-week', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId, weekIndex, clientUserId: userId }),
      });

      const json = await res.json().catch(() => null);

      if (res.status === 409) return 'conflict';

      if (res.status === 429) {
        // Rate limited: stop hammering; a later resume picks this up.
        console.warn('[enrichmentRunner] rate limited; pausing enrichment', { planId, weekIndex });
        return 'failed';
      }

      // Never broadcast success for a failed response.
      if (!res.ok || json?.ok !== true) {
        if (attempt < MAX_RETRIES_PER_WEEK) {
          await sleep(RETRY_BACKOFF_MS[attempt] ?? 3000);
          continue;
        }
        return 'failed';
      }

      if (json?.failed === true) {
        // Server kept scaffold details (LLM failure). Retry within bounds.
        if (attempt < MAX_RETRIES_PER_WEEK) {
          await sleep(RETRY_BACKOFF_MS[attempt] ?? 3000);
          continue;
        }
        return 'failed';
      }

      if (json?.alreadyEnriched === true) return 'already';

      broadcast('traingpt:week-enriched', {
        planId,
        weekIndex,
        totalWeeks,
        enrichedCount: Number(json?.enrichedCount ?? 0),
      } satisfies EnrichmentProgressDetail);

      return 'enriched';
    } catch (error) {
      console.error('[enrichmentRunner] week request failed', { planId, weekIndex, attempt, error });
      if (attempt < MAX_RETRIES_PER_WEEK) {
        await sleep(RETRY_BACKOFF_MS[attempt] ?? 3000);
        continue;
      }
      return 'failed';
    }
  }

  return 'failed';
}

async function runLoop({
  planId,
  totalWeeks,
  userId,
  skipWeeks,
}: {
  planId: string;
  totalWeeks: number;
  userId: string;
  skipWeeks: Set<number>;
}) {
  let failures = 0;

  for (let weekIndex = 0; weekIndex < totalWeeks; weekIndex++) {
    if (activeRunFor !== planId) return; // superseded by a newer plan
    if (skipWeeks.has(weekIndex)) continue;

    const result = await enrichOneWeek({ planId, weekIndex, userId, totalWeeks });

    if (result === 'superseded') return;
    if (result === 'conflict') {
      // Plan changed while we worked. Stop this loop; a fresh resume will
      // recompute enrichment state from the new plan JSON.
      console.warn('[enrichmentRunner] plan changed mid-run; stopping stale loop', { planId });
      return;
    }
    if (result === 'failed') {
      failures += 1;
      // Scaffold details for the week remain complete and executable —
      // continue with the next week rather than blocking the run.
      if (failures >= 3) {
        console.warn('[enrichmentRunner] too many failures; pausing until next resume', { planId });
        return;
      }
    }
  }

  broadcast('traingpt:enrichment-complete', { planId, totalWeeks });
}

export async function startPlanEnrichment({
  planId,
  totalWeeks,
}: {
  planId: string;
  totalWeeks: number;
}): Promise<void> {
  if (typeof window === 'undefined') return;
  if (!planId || !Number.isFinite(totalWeeks) || totalWeeks <= 0) return;
  if (activeRunFor === planId) return; // already running for this plan

  activeRunFor = planId;

  try {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    const userId = session?.user?.id;
    if (!userId) return;

    await runLoop({ planId, totalWeeks, userId, skipWeeks: new Set() });
  } finally {
    if (activeRunFor === planId) activeRunFor = null;
  }
}

/**
 * Resume enrichment for the current user's active plan if it was left
 * partially enriched (metadata.enrichment.pending === true). Safe to call on
 * every schedule load: it no-ops when there is nothing to do or a loop is
 * already running in this tab.
 */
export async function resumePlanEnrichmentIfPending(): Promise<void> {
  if (typeof window === 'undefined') return;
  if (activeRunFor !== null) return; // a loop is already running in this tab

  try {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    const userId = session?.user?.id;
    if (!userId) return;

    const { data: planRow, error } = await supabase
      .from('plans')
      .select('id, plan')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !planRow?.plan) return;

    const plan = planRow.plan as any;
    if (plan?.planType !== 'triathlon') return;

    const enrichment = plan?.metadata?.enrichment;
    if (!enrichment || enrichment.pending !== true) return;

    const totalWeeks = Array.isArray(plan?.weeks) ? plan.weeks.length : 0;
    if (totalWeeks <= 0) return;

    const enrichedWeeks: number[] = Array.isArray(enrichment.enrichedWeeks) ? enrichment.enrichedWeeks : [];
    const skipWeeks = new Set<number>(enrichedWeeks);
    if (skipWeeks.size >= totalWeeks) return;

    const planId = String(planRow.id);
    if (activeRunFor !== null) return;
    activeRunFor = planId;

    try {
      console.info('[enrichmentRunner] resuming pending enrichment', {
        planId,
        totalWeeks,
        alreadyEnriched: skipWeeks.size,
      });
      await runLoop({ planId, totalWeeks, userId, skipWeeks });
    } finally {
      if (activeRunFor === planId) activeRunFor = null;
    }
  } catch (error) {
    console.error('[enrichmentRunner] resume check failed', error);
  }
}
