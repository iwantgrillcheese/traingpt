// lib/validation/planRequest.ts
//
// Runtime validation for /api/finalize-plan input. The UI constrains these
// values, but the API must not trust the client: a race date years out would
// otherwise create hundreds of sessions and enrichment LLM calls.

import { isValidISODate, todayISOInTimeZone } from '@/lib/server/dates';

export const SUPPORTED_PLAN_TYPES = ['triathlon', 'running'] as const;

export const SUPPORTED_RACE_TYPES = [
  // Triathlon
  'Sprint', 'Olympic', 'Half Ironman (70.3)', 'Ironman (140.6)',
  // Running
  '5k', '10k', 'Half Marathon', 'Marathon',
] as const;

export const MAX_NOTES_LENGTH = 2000;
export const MAX_ARRAY_ITEMS = 20;
export const MIN_MAX_HOURS = 1;
export const MAX_MAX_HOURS = 30;
export const MIN_FTP = 50;
export const MAX_FTP = 600;

export function maxPlanWeeks(): number {
  const raw = Number(process.env.MAX_PLAN_WEEKS);
  return Number.isFinite(raw) && raw >= 4 && raw <= 104 ? Math.floor(raw) : 52;
}

export type PlanRequestErrors = string[];

export type ValidatedPlanRequest = {
  raceType: string;
  raceDate: string;
  planType: 'triathlon' | 'running';
  maxHours: number;
  bikeFTP?: number;
  clientRequestId?: string;
};

function normalizeRaceType(value: unknown): string | null {
  const text = typeof value === 'string' ? value.trim() : '';
  if (!text) return null;
  const match = SUPPORTED_RACE_TYPES.find((t) => t.toLowerCase() === text.toLowerCase());
  return match ?? null;
}

function tooLong(value: unknown, max: number): boolean {
  return typeof value === 'string' && value.length > max;
}

function paceLooksReasonable(value: unknown): boolean {
  if (value === undefined || value === null || value === '') return true;
  const match = String(value).match(/(\d{1,2})\s*:\s*(\d{2})/);
  if (!match) return false;
  const minutes = Number(match[1]);
  const seconds = Number(match[2]);
  if (seconds >= 60) return false;
  const total = minutes * 60 + seconds;
  // 2:00–20:00 per unit covers every plausible run or swim threshold input.
  return total >= 120 && total <= 1200;
}

/**
 * Validate the finalize-plan payload. Returns errors and (when valid) the
 * normalized values the route needs beyond its existing normalization.
 */
export function validatePlanRequest(body: Record<string, unknown> | null | undefined): {
  ok: boolean;
  errors: PlanRequestErrors;
  value?: ValidatedPlanRequest;
} {
  const errors: PlanRequestErrors = [];
  const source = body ?? {};

  const planTypeRaw = source.planType;
  const planType: 'triathlon' | 'running' = planTypeRaw === 'running' ? 'running' : 'triathlon';
  if (planTypeRaw !== undefined && planTypeRaw !== 'running' && planTypeRaw !== 'triathlon') {
    errors.push(`Unsupported planType. Expected one of: ${SUPPORTED_PLAN_TYPES.join(', ')}.`);
  }

  const raceType = normalizeRaceType(source.raceType);
  if (!raceType) {
    errors.push(`Unsupported or missing raceType. Expected one of: ${SUPPORTED_RACE_TYPES.join(', ')}.`);
  }

  const raceDate = typeof source.raceDate === 'string' ? source.raceDate.trim() : '';
  const today = todayISOInTimeZone();
  if (!isValidISODate(raceDate)) {
    errors.push('raceDate must be a valid YYYY-MM-DD date.');
  } else if (raceDate <= today) {
    errors.push('raceDate must be after today.');
  } else {
    const horizonMs = new Date(`${raceDate}T12:00:00Z`).getTime() - new Date(`${today}T12:00:00Z`).getTime();
    const horizonWeeks = Math.ceil(horizonMs / (7 * 24 * 60 * 60 * 1000)) + 1;
    if (horizonWeeks > maxPlanWeeks()) {
      errors.push(`raceDate is too far out. Plans are limited to ${maxPlanWeeks()} weeks.`);
    }
  }

  const maxHours = Number(source.maxHours);
  if (!Number.isFinite(maxHours) || maxHours < MIN_MAX_HOURS || maxHours > MAX_MAX_HOURS) {
    errors.push(`maxHours must be a number between ${MIN_MAX_HOURS} and ${MAX_MAX_HOURS}.`);
  }

  const ftpRaw = source.bikeFTP ?? source.bikeFtp;
  let bikeFTP: number | undefined;
  if (ftpRaw !== undefined && ftpRaw !== null && ftpRaw !== '') {
    const ftp = Number(ftpRaw);
    if (!Number.isFinite(ftp) || ftp < MIN_FTP || ftp > MAX_FTP) {
      errors.push(`bikeFTP must be between ${MIN_FTP} and ${MAX_FTP} watts.`);
    } else {
      bikeFTP = ftp;
    }
  }

  if (!paceLooksReasonable(source.runPace)) {
    errors.push('runPace must look like M:SS (e.g. 8:30) within a realistic range.');
  }
  if (!paceLooksReasonable(source.swimPace)) {
    errors.push('swimPace must look like M:SS (e.g. 1:45) within a realistic range.');
  }

  for (const field of ['athleteNotes', 'preferencesText'] as const) {
    if (tooLong(source[field], MAX_NOTES_LENGTH)) {
      errors.push(`${field} must be ${MAX_NOTES_LENGTH} characters or fewer.`);
    }
  }

  for (const field of ['unavailableDays', 'coachingPriorities'] as const) {
    const value = source[field];
    if (value !== undefined && (!Array.isArray(value) || value.length > MAX_ARRAY_ITEMS)) {
      errors.push(`${field} must be an array with at most ${MAX_ARRAY_ITEMS} items.`);
    } else if (Array.isArray(value) && value.some((item) => typeof item === 'string' && item.length > 100)) {
      errors.push(`${field} items must be 100 characters or fewer.`);
    }
  }

  const clientRequestIdRaw = source.clientRequestId;
  let clientRequestId: string | undefined;
  if (clientRequestIdRaw !== undefined && clientRequestIdRaw !== null) {
    if (typeof clientRequestIdRaw !== 'string' || clientRequestIdRaw.length > 100 || !/^[\w-]+$/.test(clientRequestIdRaw)) {
      errors.push('clientRequestId must be a short alphanumeric identifier.');
    } else {
      clientRequestId = clientRequestIdRaw;
    }
  }

  if (errors.length) return { ok: false, errors };

  return {
    ok: true,
    errors: [],
    value: {
      raceType: raceType!,
      raceDate,
      planType,
      maxHours,
      bikeFTP,
      clientRequestId,
    },
  };
}
