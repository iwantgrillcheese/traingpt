// lib/server/completion.ts
//
// Server-authoritative workout completion, shared by
// /api/schedule/mark-done and /api/schedule/mark-skip.
//
// Replaces the old identity model (session_date + session_title with a
// delete-then-insert write) with a stable sessionId-based model:
//   * The session is fetched server-side and MUST belong to the caller.
//   * Future workouts cannot be marked done/skipped (timezone-aware, using
//     the shared America/Los_Angeles fallback).
//   * Writes are atomic upserts on completed_sessions.session_id (unique
//     partial index, migration 20260710120000) — no delete-then-insert gap.
//   * Undo is idempotent: deleting an absent row still succeeds.
//   * Legacy callers that only know date+title are still accepted, but the
//     pair must resolve to exactly ONE session; ambiguity is a 409.

import type { SupabaseClient } from '@supabase/supabase-js';
import { isFutureDateISO } from '@/lib/server/dates';

export type CompletionStatus = 'done' | 'skipped';

export type CompletionRequest = {
  sessionId?: string | null;
  /** Legacy fallback identity (older mobile builds). */
  session_date?: string | null;
  session_title?: string | null;
  undo?: boolean;
};

export type CompletionOutcome =
  | { ok: true; active: boolean; sessionId: string }
  | { ok: false; status: number; error: string };

type SessionRow = {
  id: string;
  user_id: string;
  date: string;
  title: string | null;
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function resolveSession(
  supabase: SupabaseClient,
  userId: string,
  payload: CompletionRequest
): Promise<{ session: SessionRow } | { error: CompletionOutcome }> {
  const sessionId = payload.sessionId?.trim();

  if (sessionId) {
    if (!UUID_RE.test(sessionId)) {
      return { error: { ok: false, status: 400, error: 'Invalid sessionId.' } };
    }

    // Fetch first, verify ownership explicitly — never trust a raw UUID.
    const { data, error } = await supabase
      .from('sessions')
      .select('id, user_id, date, title')
      .eq('id', sessionId)
      .maybeSingle();

    if (error) {
      return { error: { ok: false, status: 500, error: 'Could not load session.' } };
    }
    if (!data || data.user_id !== userId) {
      return { error: { ok: false, status: 404, error: 'Session not found.' } };
    }
    return { session: data as SessionRow };
  }

  // Legacy identity: date + title. Must be unambiguous.
  const date = payload.session_date?.trim();
  const title = payload.session_title?.trim();
  if (!date || !title) {
    return {
      error: {
        ok: false,
        status: 400,
        error: 'Missing required fields: sessionId (preferred) or session_date + session_title.',
      },
    };
  }

  const { data, error } = await supabase
    .from('sessions')
    .select('id, user_id, date, title')
    .eq('user_id', userId)
    .eq('date', date)
    .eq('title', title)
    .limit(2);

  if (error) {
    return { error: { ok: false, status: 500, error: 'Could not load session.' } };
  }
  const rows = (data ?? []) as SessionRow[];
  if (rows.length === 0) {
    return { error: { ok: false, status: 404, error: 'Session not found.' } };
  }
  if (rows.length > 1) {
    return {
      error: {
        ok: false,
        status: 409,
        error: 'Multiple sessions share this date and title. Update the app and retry with a sessionId.',
      },
    };
  }
  return { session: rows[0] };
}

export async function applyCompletion({
  supabase,
  userId,
  payload,
  status,
  now = new Date(),
}: {
  supabase: SupabaseClient;
  userId: string;
  payload: CompletionRequest;
  status: CompletionStatus;
  now?: Date;
}): Promise<CompletionOutcome> {
  const resolved = await resolveSession(supabase, userId, payload);
  if ('error' in resolved) return resolved.error;

  const { session } = resolved;

  if (payload.undo === true) {
    // Idempotent undo: remove by stable id AND by legacy identity so rows
    // created before the session_id backfill are also cleared.
    const { error: undoByIdError } = await supabase
      .from('completed_sessions')
      .delete()
      .eq('user_id', userId)
      .eq('session_id', session.id);

    const { error: undoLegacyError } = await supabase
      .from('completed_sessions')
      .delete()
      .eq('user_id', userId)
      .is('session_id', null)
      .eq('date', session.date)
      .eq('session_title', session.title ?? '');

    if (undoByIdError || undoLegacyError) {
      console.error('[completion] undo failed', { undoByIdError, undoLegacyError });
      return { ok: false, status: 500, error: 'Could not undo completion.' };
    }

    return { ok: true, active: false, sessionId: session.id };
  }

  // Server-side future-date guard (clients also check, but must not be trusted).
  if (isFutureDateISO(session.date, undefined, now)) {
    return {
      ok: false,
      status: 400,
      error: 'Future workouts cannot be marked yet. Wait until the workout day.',
    };
  }

  // Clear any legacy row for the same session so the upsert below is the
  // single source of truth, then atomically upsert on session_id.
  await supabase
    .from('completed_sessions')
    .delete()
    .eq('user_id', userId)
    .is('session_id', null)
    .eq('date', session.date)
    .eq('session_title', session.title ?? '');

  const { error: upsertError } = await supabase
    .from('completed_sessions')
    .upsert(
      {
        user_id: userId,
        session_id: session.id,
        date: session.date,
        session_title: session.title ?? '',
        status,
      },
      { onConflict: 'session_id' }
    );

  if (upsertError) {
    console.error('[completion] upsert failed', upsertError);
    return { ok: false, status: 500, error: upsertError.message };
  }

  return { ok: true, active: true, sessionId: session.id };
}
