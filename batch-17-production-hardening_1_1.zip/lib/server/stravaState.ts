// lib/server/stravaState.ts
//
// One signed, expiring OAuth `state` implementation shared by web and mobile
// Strava connect flows. Replaces the previous mix of raw return-path web state
// and a mobile-only HMAC format.
//
// Format: `<kind>.<base64url(payload)>.<hmac-sha256(base64url(payload))>`
//   kind = "web" | "mobile"
//
// Payloads are bound to the authenticated TrainGPT user and expire after
// STATE_TTL_MS. In production the signing secret must be explicitly
// configured; there is no fallback to unrelated keys or dev constants.

import { createHmac, timingSafeEqual } from 'crypto';

export const STATE_TTL_MS = 20 * 60 * 1000;

export type WebStravaState = {
  type: 'web';
  userId: string;
  returnTo: string;
  createdAt: number;
};

export type MobileStravaState = {
  type: 'mobile';
  userId: string;
  appRedirect: string;
  createdAt: number;
};

export type StravaState = WebStravaState | MobileStravaState;

function isProduction() {
  return process.env.VERCEL_ENV === 'production' || process.env.NODE_ENV === 'production';
}

export function stravaStateSecret(): string {
  const secret = process.env.STRAVA_STATE_SECRET?.trim() || process.env.NEXTAUTH_SECRET?.trim();

  if (secret) return secret;

  if (isProduction()) {
    // Fail closed: never sign OAuth state with a guessable constant or an
    // unrelated credential in production.
    throw new Error('STRAVA_STATE_SECRET (or NEXTAUTH_SECRET) must be set in production.');
  }

  console.warn('[strava-state] Using development-only state secret. Set STRAVA_STATE_SECRET for production.');
  return 'traingpt-strava-dev-only-secret';
}

function sign(payload: string): string {
  return createHmac('sha256', stravaStateSecret()).update(payload).digest('base64url');
}

function safeEquals(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}

/** Only allow same-origin absolute paths as post-connect return targets. */
export function sanitizeReturnTo(raw: unknown, fallback = '/coaching'): string {
  const value = typeof raw === 'string' ? raw.trim() : '';
  if (!value.startsWith('/') || value.startsWith('//') || value.includes('\\')) return fallback;
  if (/[\r\n]/.test(value)) return fallback;
  return value;
}

export function createWebState({ userId, returnTo }: { userId: string; returnTo: string }): string {
  const payload: WebStravaState = {
    type: 'web',
    userId,
    returnTo: sanitizeReturnTo(returnTo),
    createdAt: Date.now(),
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  return `web.${encoded}.${sign(encoded)}`;
}

export function createMobileState({ userId, appRedirect }: { userId: string; appRedirect: string }): string {
  const payload: MobileStravaState = {
    type: 'mobile',
    userId,
    appRedirect,
    createdAt: Date.now(),
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  return `mobile.${encoded}.${sign(encoded)}`;
}

/**
 * Parse and verify a signed state. Returns null for missing, malformed,
 * incorrectly signed, expired, or semantically invalid states.
 */
export function parseSignedState(raw: string | null, now: number = Date.now()): StravaState | null {
  if (!raw) return null;

  const parts = raw.split('.');
  if (parts.length !== 3) return null;

  const [kind, encoded, signature] = parts;
  if ((kind !== 'web' && kind !== 'mobile') || !encoded || !signature) return null;

  let expected: string;
  try {
    expected = sign(encoded);
  } catch {
    return null;
  }
  if (!safeEquals(signature, expected)) return null;

  let parsed: StravaState;
  try {
    parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as StravaState;
  } catch {
    return null;
  }

  if (parsed.type !== kind) return null;
  if (typeof parsed.userId !== 'string' || !parsed.userId) return null;

  const ageMs = now - Number(parsed.createdAt ?? 0);
  if (!Number.isFinite(ageMs) || ageMs < 0 || ageMs > STATE_TTL_MS) return null;

  if (parsed.type === 'mobile') {
    if (typeof parsed.appRedirect !== 'string' || !parsed.appRedirect.startsWith('traingpt://')) return null;
  } else {
    parsed.returnTo = sanitizeReturnTo(parsed.returnTo);
  }

  return parsed;
}
