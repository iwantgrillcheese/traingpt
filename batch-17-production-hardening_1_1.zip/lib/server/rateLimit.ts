// lib/server/rateLimit.ts
//
// Durable, per-user usage limiting for expensive (LLM-backed) routes.
// Backed by the `api_usage_events` table (see migration
// 20260710120000_security_hardening.sql) so limits survive across ephemeral
// Vercel instances — an in-memory counter would silently reset on every cold
// start.
//
// Only successful authorizations should be counted: call this AFTER
// requireUser() has succeeded.

import { createClient, type SupabaseClient } from '@supabase/supabase-js';

export type RateLimitDecision =
  | { allowed: true }
  | { allowed: false; retryAfterSeconds: number; message: string };

export type RateLimitRule = {
  /** Max successful calls per window. */
  limit: number;
  /** Window length in seconds. */
  windowSeconds: number;
};

function envInt(name: string, fallback: number): number {
  const raw = Number(process.env[name]);
  return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : fallback;
}

/** Configurable defaults per route (env overrides: RATE_LIMIT_<NAME>__LIMIT / __WINDOW_SECONDS). */
export function ruleForRoute(route: string): RateLimitRule {
  const key = route.replace(/^\/+|\/+$/g, '').replace(/[^a-zA-Z0-9]+/g, '_').toUpperCase();
  const defaults: Record<string, RateLimitRule> = {
    API_FINALIZE_PLAN: { limit: 6, windowSeconds: 60 * 60 },
    API_ENRICH_WEEK: { limit: 120, windowSeconds: 60 * 60 },
    API_GENERATE_DETAILED_SESSION: { limit: 30, windowSeconds: 60 * 60 },
    API_STRAVA_ANALYZE: { limit: 20, windowSeconds: 60 * 60 },
    API_COACH_CHAT: { limit: 60, windowSeconds: 60 * 60 },
  };
  const fallback: RateLimitRule = { limit: 30, windowSeconds: 60 * 60 };
  const base = defaults[key] ?? fallback;

  return {
    limit: envInt(`RATE_LIMIT_${key}__LIMIT`, base.limit),
    windowSeconds: envInt(`RATE_LIMIT_${key}__WINDOW_SECONDS`, base.windowSeconds),
  };
}

let cachedAdmin: SupabaseClient | null = null;

function adminClient(): SupabaseClient | null {
  if (cachedAdmin) return cachedAdmin;
  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  cachedAdmin = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  return cachedAdmin;
}

/**
 * Check and consume one unit of usage for (userId, route).
 *
 * Fail-open on infrastructure errors (a broken limiter must not take down
 * plan generation), fail-closed only on a genuine over-limit count.
 */
export async function checkAndConsumeRateLimit({
  userId,
  route,
  rule,
  client,
}: {
  userId: string;
  route: string;
  rule?: RateLimitRule;
  /** Injectable for tests. */
  client?: SupabaseClient | null;
}): Promise<RateLimitDecision> {
  const effectiveRule = rule ?? ruleForRoute(route);
  const supabase = client !== undefined ? client : adminClient();

  if (!supabase) {
    console.error('[rate-limit] service role client unavailable; allowing request', { route });
    return { allowed: true };
  }

  const windowStartISO = new Date(Date.now() - effectiveRule.windowSeconds * 1000).toISOString();

  try {
    const { count, error: countError } = await supabase
      .from('api_usage_events')
      .select('id', { head: true, count: 'exact' })
      .eq('user_id', userId)
      .eq('route', route)
      .gte('created_at', windowStartISO);

    if (countError) {
      console.error('[rate-limit] count failed; allowing request', { route, error: countError.message });
      return { allowed: true };
    }

    if ((count ?? 0) >= effectiveRule.limit) {
      return {
        allowed: false,
        retryAfterSeconds: effectiveRule.windowSeconds,
        message: `You've hit the limit for this action (${effectiveRule.limit} per ${Math.round(effectiveRule.windowSeconds / 60)} minutes). Please try again later.`,
      };
    }

    const { error: insertError } = await supabase
      .from('api_usage_events')
      .insert({ user_id: userId, route });

    if (insertError) {
      console.error('[rate-limit] insert failed; allowing request', { route, error: insertError.message });
    }

    return { allowed: true };
  } catch (error) {
    console.error('[rate-limit] unexpected failure; allowing request', {
      route,
      error: error instanceof Error ? error.message : String(error),
    });
    return { allowed: true };
  }
}
