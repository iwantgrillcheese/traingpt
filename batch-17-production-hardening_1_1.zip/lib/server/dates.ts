// lib/server/dates.ts
//
// Shared date helpers for server routes. Until per-user timezones are stored
// reliably, all "what day is it for the athlete" decisions use a single
// reference timezone, defaulting to America/Los_Angeles (overridable through
// DAILY_EMAIL_TIMEZONE, which the email crons already use).

export const FALLBACK_TIMEZONE = 'America/Los_Angeles';

export function referenceTimeZone(): string {
  return process.env.DAILY_EMAIL_TIMEZONE?.trim() || FALLBACK_TIMEZONE;
}

/** Today's date (YYYY-MM-DD) in the given IANA timezone. */
export function todayISOInTimeZone(timeZone: string = referenceTimeZone(), now: Date = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(now);
}

/** True when `dateISO` (YYYY-MM-DD) is strictly after today in the reference timezone. */
export function isFutureDateISO(dateISO: string, timeZone: string = referenceTimeZone(), now: Date = new Date()): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateISO)) return false;
  return dateISO > todayISOInTimeZone(timeZone, now);
}

/** Validate a plain YYYY-MM-DD string represents a real calendar date. */
export function isValidISODate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T12:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}
