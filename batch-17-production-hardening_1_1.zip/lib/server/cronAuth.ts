// lib/server/cronAuth.ts
//
// Shared, fail-closed authorization for Vercel cron routes.
//
// Rules:
// - In production, a missing CRON_SECRET is a configuration error: every
//   request is rejected (503) and the misconfiguration is logged. We never
//   fall open.
// - Authorization must arrive as `Authorization: Bearer <CRON_SECRET>`
//   (this is exactly what Vercel sends when CRON_SECRET is set).
// - Query-string secrets are never accepted in production. In local
//   development they are accepted only when ALLOW_INSECURE_CRON=true, so
//   `curl "localhost:3000/api/adapt-week?secret=..."` still works on a laptop.
// - The secret value itself is never logged or echoed in a response.

import { timingSafeEqual } from 'crypto';

export type CronAuthResult =
  | { ok: true }
  | { ok: false; status: number; error: string };

function isProduction() {
  return process.env.VERCEL_ENV === 'production' || process.env.NODE_ENV === 'production';
}

function safeEquals(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

/**
 * Authorize a cron-triggered request. Works with both `Request` and
 * `NextRequest` (only `headers` and `url` are used).
 */
export function authorizeCronRequest(req: Request, routeName: string): CronAuthResult {
  const cronSecret = process.env.CRON_SECRET?.trim();
  const prod = isProduction();

  if (!cronSecret) {
    if (prod) {
      // Fail closed and make the misconfiguration loud (without the secret,
      // because there is none to leak).
      console.error(
        `[cron-auth] ${routeName}: CRON_SECRET is not configured in production. Rejecting request.`
      );
      return { ok: false, status: 503, error: 'Cron authorization is not configured.' };
    }

    // Local development only: explicit, opt-in escape hatch.
    if (process.env.ALLOW_INSECURE_CRON === 'true') {
      console.warn(`[cron-auth] ${routeName}: ALLOW_INSECURE_CRON=true — allowing unauthenticated local cron call.`);
      return { ok: true };
    }

    console.error(
      `[cron-auth] ${routeName}: CRON_SECRET missing. Set CRON_SECRET, or set ALLOW_INSECURE_CRON=true for local development.`
    );
    return { ok: false, status: 503, error: 'Cron authorization is not configured.' };
  }

  const header = req.headers.get('authorization') ?? '';
  const bearer = header.startsWith('Bearer ') ? header.slice(7).trim() : '';

  if (bearer && safeEquals(bearer, cronSecret)) {
    return { ok: true };
  }

  // Query-param secrets: local development convenience only, never production.
  if (!prod && process.env.ALLOW_INSECURE_CRON === 'true') {
    try {
      const query = new URL(req.url).searchParams.get('secret') ?? '';
      if (query && safeEquals(query, cronSecret)) {
        console.warn(`[cron-auth] ${routeName}: accepted query-param secret (local development only).`);
        return { ok: true };
      }
    } catch {
      // fall through to rejection
    }
  }

  console.error(`[cron-auth] ${routeName}: rejected request with missing or invalid bearer token.`);
  return { ok: false, status: 401, error: 'Unauthorized' };
}
