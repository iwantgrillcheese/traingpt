// lib/stravaConnect.ts
//
// Client-side helpers for the hardened Strava connection flow:
//   * startStravaConnect() asks the server for an authorize URL carrying a
//     signed, expiring OAuth state (no more raw return-path state built in
//     the browser).
//   * fetchStravaStatus() returns booleans/safe metadata so components no
//     longer SELECT raw access tokens just to know whether Strava is
//     connected.

'use client';

export type StravaStatus = {
  connected: boolean;
  athleteId: number | string | null;
  expiresAt: number | string | null;
};

export async function startStravaConnect(returnTo?: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch('/api/strava/connect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ returnTo: returnTo ?? `${window.location.pathname}${window.location.search}` }),
    });

    const json = await res.json().catch(() => null);

    if (!res.ok || !json?.url) {
      return { ok: false, error: json?.error || 'Could not start Strava connection.' };
    }

    window.location.href = json.url;
    return { ok: true };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : 'Could not start Strava connection.' };
  }
}

export async function fetchStravaStatus(): Promise<StravaStatus> {
  try {
    const res = await fetch('/api/strava/status', { cache: 'no-store' });
    const json = await res.json().catch(() => null);
    if (!res.ok || !json) return { connected: false, athleteId: null, expiresAt: null };
    return {
      connected: Boolean(json.connected),
      athleteId: json.athleteId ?? null,
      expiresAt: json.expiresAt ?? null,
    };
  } catch {
    return { connected: false, athleteId: null, expiresAt: null };
  }
}
