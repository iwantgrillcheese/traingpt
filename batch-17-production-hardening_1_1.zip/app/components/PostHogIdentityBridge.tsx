'use client';

import { useEffect, useRef } from 'react';
import { identify, initPostHog, reset, track } from '@/lib/analytics/posthog-client';
import { createBrowserSupabaseClient } from '@/lib/supabase/client';
import { fetchStravaStatus } from '@/lib/stravaConnect';
import { useAuth } from '@/lib/auth/AuthProvider';

export default function PostHogIdentityBridge(): null {
  const { user } = useAuth();
  const supabase = createBrowserSupabaseClient();

  const lastIdentifiedUserId = useRef<string | null>(null);
  const trackedLoginForUserId = useRef<string | null>(null);

  useEffect(() => {
    initPostHog();
  }, []);

  useEffect(() => {
    let cancelled = false;

    const syncIdentity = async () => {
      if (!user?.id) {
        reset();
        lastIdentifiedUserId.current = null;
        trackedLoginForUserId.current = null;
        return;
      }

      if (lastIdentifiedUserId.current === user.id) {
        return;
      }

      try {
        const [stravaStatus, { data: latestPlanData }] = await Promise.all([
          fetchStravaStatus(),
          supabase
            .from('plans')
            .select('id')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle(),
        ]);

        if (cancelled) return;

        identify({
          id: user.id,
          email: user.email,
          created_at: user.created_at,
          has_strava: stravaStatus.connected,
          has_plan: !!latestPlanData?.id,
        });

        lastIdentifiedUserId.current = user.id;

        if (trackedLoginForUserId.current !== user.id) {
          const createdAt = new Date(user.created_at || 0).getTime();
          const lastSignInAt = new Date(user.last_sign_in_at || 0).getTime();

          const looksLikeSignup =
            Number.isFinite(createdAt) &&
            Number.isFinite(lastSignInAt) &&
            Math.abs(lastSignInAt - createdAt) < 120000;

          track(looksLikeSignup ? 'user_signed_up' : 'user_logged_in');
          trackedLoginForUserId.current = user.id;
        }
      } catch (error) {
        console.error('[PostHogIdentityBridge] identity sync failed:', error);
      }
    };

    syncIdentity();

    return () => {
      cancelled = true;
    };
  }, [user, supabase]);

  return null;
}
