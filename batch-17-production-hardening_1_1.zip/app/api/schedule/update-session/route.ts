import { NextResponse } from 'next/server';
import {
  AuthError,
  assertSameUser,
  createRouteSupabaseClient,
  requireUser,
} from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

type UpdateSessionPayload = {
  sessionId?: string;
  newDate?: string;
  clientUserId?: string | null;
};

export async function POST(req: Request) {
  try {
    const supabase = await createRouteSupabaseClient();
    const user = await requireUser(supabase);

    const payload = (await req.json()) as UpdateSessionPayload;

    assertSameUser({
      authenticatedUserId: user.id,
      requestedUserId: payload.clientUserId,
      routeName: 'schedule/update-session',
    });

    const sessionId = payload.sessionId?.trim();
    const newDate = payload.newDate?.trim();

    if (!sessionId || !newDate) {
      return NextResponse.json(
        { error: 'Missing required fields: sessionId and newDate are required.' },
        { status: 400 }
      );
    }

    // Fetch-first ownership verification: never act on a raw client-supplied
    // UUID without confirming the session belongs to the authenticated user.
    const { data: existing, error: fetchError } = await supabase
      .from('sessions')
      .select('id, user_id')
      .eq('id', sessionId)
      .maybeSingle();

    if (fetchError) {
      console.error('[schedule/update-session] fetch failed:', fetchError);
      return NextResponse.json({ error: 'Could not load session.' }, { status: 500 });
    }

    if (!existing || existing.user_id !== user.id) {
      return NextResponse.json({ error: 'Session not found.' }, { status: 404 });
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(newDate)) {
      return NextResponse.json({ error: 'newDate must be YYYY-MM-DD.' }, { status: 400 });
    }

    const { error } = await supabase
      .from('sessions')
      .update({ date: newDate })
      .eq('id', sessionId)
      .eq('user_id', user.id);

    if (error) {
      console.error('[schedule/update-session] update failed:', error);

      return NextResponse.json(
        { error: error.message },
        { status: 400 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('[schedule/update-session] failed:', error);

    if (error instanceof AuthError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.status }
      );
    }

    return NextResponse.json(
      { error: 'Failed to update session.' },
      { status: 500 }
    );
  }
}