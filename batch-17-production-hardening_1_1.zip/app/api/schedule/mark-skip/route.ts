import { NextResponse } from 'next/server';
import {
  AuthError,
  assertSameUser,
  createRouteSupabaseClient,
  requireUser,
} from '@/lib/supabase/server';
import { applyCompletion, type CompletionRequest } from '@/lib/server/completion';

export const dynamic = 'force-dynamic';

type Payload = CompletionRequest & { clientUserId?: string | null };

export async function POST(req: Request) {
  try {
    const supabase = await createRouteSupabaseClient(req);
    const user = await requireUser(supabase);

    const payload = (await req.json()) as Payload;

    assertSameUser({
      authenticatedUserId: user.id,
      requestedUserId: payload.clientUserId,
      routeName: 'schedule/mark-skip',
    });

    const outcome = await applyCompletion({
      supabase,
      userId: user.id,
      payload,
      status: 'skipped',
    });

    if (!outcome.ok) {
      return NextResponse.json({ error: outcome.error }, { status: outcome.status });
    }

    return NextResponse.json({ success: true, skipped: outcome.active, sessionId: outcome.sessionId });
  } catch (error) {
    console.error('[schedule/mark-skip] failed:', error);

    if (error instanceof AuthError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }

    return NextResponse.json({ error: 'Failed to update completion status.' }, { status: 500 });
  }
}
