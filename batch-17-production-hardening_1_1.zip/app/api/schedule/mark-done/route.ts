import { NextResponse } from 'next/server';
import {
  AuthError,
  assertSameUser,
  createRouteSupabaseClient,
  requireUser,
} from '@/lib/supabase/server';
import { applyCompletion, type CompletionRequest } from '@/lib/server/completion';

export const dynamic = 'force-dynamic';

type Payload = CompletionRequest & { clientUserId?: string | null };

export async function POST(req: Request) {
  try {
    const supabase = await createRouteSupabaseClient(req);
    const user = await requireUser(supabase);

    const payload = (await req.json()) as Payload;

    assertSameUser({
      authenticatedUserId: user.id,
      requestedUserId: payload.clientUserId,
      routeName: 'schedule/mark-done',
    });

    const outcome = await applyCompletion({
      supabase,
      userId: user.id,
      payload,
      status: 'done',
    });

    if (!outcome.ok) {
      return NextResponse.json({ error: outcome.error }, { status: outcome.status });
    }

    return NextResponse.json({ success: true, completed: outcome.active, sessionId: outcome.sessionId });
  } catch (error) {
    console.error('[schedule/mark-done] failed:', error);

    if (error instanceof AuthError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }

    return NextResponse.json({ error: 'Failed to update completion status.' }, { status: 500 });
  }
}
