// /app/api/account/delete/route.ts
//
// Authenticated, server-side account deletion. Replaces the old settings-page
// flow that ran partial client-side deletes (plans, completed_sessions, users)
// and never removed the Supabase Auth user or the rest of the athlete's data.
//
// Requirements enforced here:
//   * A valid, verified session (Supabase access tokens live ~1 hour, so a
//     verified token is inherently recent) plus an explicit confirmation
//     phrase in the request body.
//   * All service-role work happens on the server; the browser never sees the
//     service-role key.
//   * TrainGPT-owned data is deleted in dependency-safe order; the Auth user
//     is deleted last.
//   * Partial failures are reported per table instead of claiming success.

import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { AuthError, createRouteSupabaseClient, requireUser } from '@/lib/supabase/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const CONFIRM_PHRASE = 'DELETE';

// Child tables first, parents last. Tables that may not exist in every
// environment are tolerated (missing-relation errors are treated as skipped).
const USER_DATA_TABLES: Array<{ table: string; column: string }> = [
  { table: 'completed_sessions', column: 'user_id' },
  { table: 'plan_adaptations', column: 'user_id' },
  { table: 'api_usage_events', column: 'user_id' },
  { table: 'sessions', column: 'user_id' },
  { table: 'strava_activities', column: 'user_id' },
  { table: 'oura_daily_readiness', column: 'user_id' },
  { table: 'plans', column: 'user_id' },
  { table: 'profiles', column: 'id' },
  { table: 'users', column: 'id' },
];

function isMissingRelationError(message: string | undefined) {
  const text = String(message ?? '').toLowerCase();
  return text.includes('does not exist') || text.includes('could not find the table') || text.includes('relation');
}

export async function POST(req: Request) {
  try {
    const supabase = await createRouteSupabaseClient(req);
    const user = await requireUser(supabase);

    const body = await req.json().catch(() => ({}));
    if (body?.confirm !== CONFIRM_PHRASE) {
      return NextResponse.json(
        { ok: false, error: `Confirmation required. Send { "confirm": "${CONFIRM_PHRASE}" }.` },
        { status: 400 }
      );
    }

    const supabaseUrl = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !serviceRoleKey) {
      console.error('[account/delete] service role configuration missing');
      return NextResponse.json(
        { ok: false, error: 'Account deletion is temporarily unavailable.' },
        { status: 503 }
      );
    }

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const results: Record<string, { status: 'deleted' | 'skipped' | 'failed'; error?: string }> = {};
    let anyFailure = false;

    for (const { table, column } of USER_DATA_TABLES) {
      const { error } = await admin.from(table).delete().eq(column, user.id);
      if (!error) {
        results[table] = { status: 'deleted' };
      } else if (isMissingRelationError(error.message)) {
        results[table] = { status: 'skipped' };
      } else {
        anyFailure = true;
        results[table] = { status: 'failed', error: error.message };
        console.error('[account/delete] table delete failed', { table, error: error.message });
      }
    }

    if (anyFailure) {
      // Do NOT delete the Auth user while data deletion is incomplete — the
      // user could no longer sign in to retry, stranding their data.
      return NextResponse.json(
        {
          ok: false,
          error: 'Some of your data could not be deleted. Your account was NOT removed — please try again or contact support.',
          results,
        },
        { status: 500 }
      );
    }

    const { error: authError } = await admin.auth.admin.deleteUser(user.id);
    if (authError) {
      console.error('[account/delete] auth user deletion failed', authError);
      return NextResponse.json(
        {
          ok: false,
          error: 'Your training data was deleted, but the login account could not be removed. Please contact support.',
          results,
        },
        { status: 500 }
      );
    }

    return NextResponse.json({ ok: true, results });
  } catch (error) {
    if (error instanceof AuthError) {
      return NextResponse.json({ ok: false, error: error.message }, { status: error.status });
    }
    console.error('[account/delete] failed', error);
    return NextResponse.json({ ok: false, error: 'Account deletion failed.' }, { status: 500 });
  }
}
