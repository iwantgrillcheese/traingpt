// /app/api/strava/status/route.ts
//
// Authenticated connection-status endpoint. Returns booleans and safe
// metadata so client components no longer SELECT the raw
// strava_access_token merely to know whether Strava is connected.
// Access and refresh tokens are never exposed to the browser.

import { NextResponse } from 'next/server';
import { AuthError, createRouteSupabaseClient, requireUser } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET(req: Request) {
  try {
    const supabase = await createRouteSupabaseClient(req);
    const user = await requireUser(supabase);

    const { data: profile, error } = await supabase
      .from('profiles')
      .select('strava_athlete_id, strava_expires_at, strava_access_token')
      .eq('id', user.id)
      .maybeSingle();

    if (error) {
      console.error('[strava/status] profile lookup failed:', error);
      return NextResponse.json({ error: 'Could not load Strava status.' }, { status: 500 });
    }

    const connected = Boolean(profile?.strava_access_token);

    return NextResponse.json({
      connected,
      athleteId: connected ? profile?.strava_athlete_id ?? null : null,
      expiresAt: connected ? profile?.strava_expires_at ?? null : null,
    });
  } catch (error) {
    if (error instanceof AuthError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    console.error('[strava/status] failed:', error);
    return NextResponse.json({ error: 'Could not load Strava status.' }, { status: 500 });
  }
}
