// /app/api/strava/callback/route.ts
//
// Strava OAuth callback for BOTH web and mobile. State must be a signed,
// expiring token created by /api/strava/connect (web) or
// /api/strava/mobile-connect (mobile) — see lib/server/stravaState. Unsigned,
// malformed, expired, or wrongly signed state is rejected before any token
// exchange, and web state must match the authenticated user.

import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import {
  AuthError,
  createRouteSupabaseClient,
  requireUser,
} from '@/lib/supabase/server';
import { parseSignedState } from '@/lib/server/stravaState';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

function getBaseUrl(req: Request): string {
  const reqUrl = new URL(req.url);
  const forwardedProto = req.headers.get('x-forwarded-proto') ?? reqUrl.protocol.replace(':', '');
  const forwardedHost = req.headers.get('x-forwarded-host') ?? reqUrl.host;
  if (forwardedHost) return `${forwardedProto}://${forwardedHost}`;
  return process.env.NEXT_PUBLIC_BASE_URL?.trim() || reqUrl.origin;
}

function redirectWithParams({ baseUrl, returnTo, params }: { baseUrl: string; returnTo: string; params: Record<string, string> }) {
  const redirectUrl = new URL(returnTo, baseUrl);
  for (const [key, value] of Object.entries(params)) if (!redirectUrl.searchParams.has(key)) redirectUrl.searchParams.set(key, value);
  return NextResponse.redirect(redirectUrl);
}

function redirectToApp(appRedirect: string, params: Record<string, string>) {
  const redirectUrl = new URL(appRedirect);
  for (const [key, value] of Object.entries(params)) redirectUrl.searchParams.set(key, value);
  return NextResponse.redirect(redirectUrl);
}

function createServiceSupabaseClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceRoleKey) throw new Error('supabase_service_role_missing');
  return createClient(url, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } });
}

async function exchangeStravaToken(code: string) {
  if (!process.env.STRAVA_CLIENT_ID || !process.env.STRAVA_CLIENT_SECRET) throw new Error('strava_server_config');
  const tokenRes = await fetch('https://www.strava.com/oauth/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      client_id: process.env.STRAVA_CLIENT_ID,
      client_secret: process.env.STRAVA_CLIENT_SECRET,
      code,
      grant_type: 'authorization_code',
    }),
  });
  const tokenData = await tokenRes.json();
  if (!tokenRes.ok) {
    console.error('[strava/callback] token exchange failed:', tokenData);
    throw new Error('strava_token_failed');
  }
  return tokenData;
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  const rawState = url.searchParams.get('state');
  const state = parseSignedState(rawState);
  const baseUrl = getBaseUrl(req);

  // Reject the connection BEFORE any token exchange when state is missing,
  // malformed, expired, or incorrectly signed.
  if (!state) {
    console.error('[strava/callback] rejected invalid or expired OAuth state');
    return redirectWithParams({ baseUrl, returnTo: '/settings', params: { error: 'invalid_state' } });
  }

  const returnTo = state.type === 'web' ? state.returnTo : '/settings';

  if (!code) {
    if (state.type === 'mobile') return redirectToApp(state.appRedirect, { error: 'missing_code' });
    return redirectWithParams({ baseUrl, returnTo, params: { error: 'missing_code' } });
  }

  try {
    if (state.type === 'mobile') {
      const tokenData = await exchangeStravaToken(code);
      const { access_token, refresh_token, expires_at, athlete } = tokenData;
      if (!access_token || !refresh_token) throw new Error('strava_token_missing');

      const supabase = createServiceSupabaseClient();
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          strava_access_token: access_token,
          strava_refresh_token: refresh_token,
          strava_expires_at: expires_at,
          strava_athlete_id: athlete?.id ?? null,
        })
        .eq('id', state.userId);

      if (updateError) {
        console.error('[strava/callback] mobile profile update failed:', updateError);
        return redirectToApp(state.appRedirect, { error: 'strava_profile_update_failed' });
      }
      return redirectToApp(state.appRedirect, { success: 'strava_connected', sync: 'needed' });
    }

    // Web: the browser session must belong to the SAME user the state was
    // issued for — a signed state cannot be replayed against another account.
    const supabase = await createRouteSupabaseClient();
    const user = await requireUser(supabase);

    if (user.id !== state.userId) {
      console.error('[strava/callback] state user mismatch', { stateUser: state.userId, sessionUser: user.id });
      return redirectWithParams({ baseUrl, returnTo, params: { error: 'state_user_mismatch' } });
    }

    const tokenData = await exchangeStravaToken(code);
    const { access_token, refresh_token, expires_at, athlete } = tokenData;
    if (!access_token || !refresh_token) throw new Error('strava_token_missing');

    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        strava_access_token: access_token,
        strava_refresh_token: refresh_token,
        strava_expires_at: expires_at,
        strava_athlete_id: athlete?.id ?? null,
      })
      .eq('id', user.id);

    if (updateError) {
      console.error('[strava/callback] profile update failed:', updateError);
      return redirectWithParams({ baseUrl, returnTo, params: { error: 'strava_profile_update_failed' } });
    }
    return redirectWithParams({ baseUrl, returnTo, params: { success: 'strava_connected', sync: 'needed' } });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'unexpected_error';
    console.error('[strava/callback] failed:', error);
    if (state.type === 'mobile') return redirectToApp(state.appRedirect, { error: message || 'unexpected_error' });
    if (error instanceof AuthError) return redirectWithParams({ baseUrl, returnTo, params: { error: 'no_user_session' } });
    return redirectWithParams({ baseUrl, returnTo, params: { error: message || 'unexpected_error' } });
  }
}
