// /app/api/strava/connect/route.ts
//
// Authenticated starting point for the WEB Strava OAuth flow. Issues a
// signed, expiring `state` bound to the TrainGPT user (replacing the old raw
// return-path state, which was neither signed nor expiring) and returns the
// Strava authorize URL for the client to redirect to.

import { NextResponse } from 'next/server';
import { AuthError, createRouteSupabaseClient, requireUser } from '@/lib/supabase/server';
import { createWebState, sanitizeReturnTo } from '@/lib/server/stravaState';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

function getBaseUrl(req: Request): string {
  const reqUrl = new URL(req.url);
  const forwardedProto = req.headers.get('x-forwarded-proto') ?? reqUrl.protocol.replace(':', '');
  const forwardedHost = req.headers.get('x-forwarded-host') ?? reqUrl.host;
  return forwardedHost ? `${forwardedProto}://${forwardedHost}` : process.env.NEXT_PUBLIC_BASE_URL?.trim() || reqUrl.origin;
}

export async function POST(req: Request) {
  try {
    const supabase = await createRouteSupabaseClient(req);
    const user = await requireUser(supabase);

    const clientId = process.env.STRAVA_CLIENT_ID || process.env.NEXT_PUBLIC_STRAVA_CLIENT_ID;
    if (!clientId) {
      return NextResponse.json({ error: 'Strava is not configured.' }, { status: 500 });
    }

    const body = await req.json().catch(() => ({}));
    const returnTo = sanitizeReturnTo(body?.returnTo);

    const state = createWebState({ userId: user.id, returnTo });
    const redirectUri = `${getBaseUrl(req)}/api/strava/callback`;

    const url = new URL('https://www.strava.com/oauth/authorize');
    url.searchParams.set('client_id', String(clientId));
    url.searchParams.set('response_type', 'code');
    url.searchParams.set('redirect_uri', redirectUri);
    url.searchParams.set('scope', 'activity:read_all,profile:read_all');
    url.searchParams.set('approval_prompt', 'auto');
    url.searchParams.set('state', state);

    return NextResponse.json({ url: url.toString() });
  } catch (error) {
    console.error('[strava/connect] failed:', error);
    if (error instanceof AuthError) {
      return NextResponse.json({ error: error.message }, { status: error.status });
    }
    return NextResponse.json({ error: 'Could not start Strava connection.' }, { status: 500 });
  }
}
