# Batch 17 — Production Hardening (security + data integrity)

## Apply (from repo root in Codespaces)

```bash
unzip -o batch-17-production-hardening_1.zip -d .
git rm app/api/send-email/welcome/route.ts app/api/send-welcome-email/route.ts lib/emails/WelcomeEmail.tsx lib/emails/generateWelcomeEmail.tsx lib/emails/send-welcome-email.ts
git add -A && git commit -m "Batch 17: production hardening — cron auth, atomic plan replacement, server-authoritative completion, signed Strava state, rate limits, tests" && git push
```

(The `git rm` line is new for this batch — it removes the legacy welcome-email
open relay, which an unzip can't delete.)

## BEFORE deploying: apply migrations + env vars

1. Run both migrations against Supabase (in order):
   - `supabase/migrations/20260710120000_security_hardening.sql`
   - `supabase/migrations/20260710121000_replace_plan_atomic.sql`
   (`supabase db push`, or paste into the SQL editor.)
2. In Vercel, make sure these exist in production:
   - `CRON_SECRET` (crons now fail closed without it)
   - `STRAVA_STATE_SECRET` (any long random string; Strava connect refuses to
     run in prod without it)

## After merging

- `yarn install` (yarn.lock changed — vitest was added)
- `yarn verify` runs lint + typecheck + tests + build (all green as shipped)
- Ship a new mobile build when convenient; old builds keep working.

Full details: `docs/PRODUCTION_HARDENING_2026-07.md`
