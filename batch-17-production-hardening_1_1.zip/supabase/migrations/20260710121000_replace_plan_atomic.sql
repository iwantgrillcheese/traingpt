-- 20260710121000_replace_plan_atomic.sql
--
-- Atomic plan replacement. Replaces the finalize-plan sequence of
-- "upsert plan → delete ALL user sessions → insert sessions", which could
-- (a) leave an athlete with an empty schedule if the insert failed and
-- (b) destroy manually created sessions that were never part of a generated
-- plan.
--
-- Guarantees:
--   * Runs in one transaction: any failure rolls everything back, so the
--     previous plan + schedule stay intact.
--   * Only sessions belonging to the superseded generated plan are replaced
--     (plan_id match). Manual sessions (plan_id IS NULL or a different plan)
--     are preserved.
--   * Idempotent: repeat submissions with the same client_request_id return
--     the existing result without duplicating sessions.
--   * Serialized per user via an advisory transaction lock, so double-clicks
--     and retries cannot interleave.
--   * SECURITY DEFINER with an explicit auth.uid() check: callable through
--     PostgREST with the user's JWT regardless of RLS configuration, but only
--     for the caller's own data. The service role (auth.uid() IS NULL) may
--     act on behalf of an explicit user id.

create or replace function public.replace_plan_atomic(
  p_user_id uuid,
  p_race_date date,
  p_race_type text,
  p_plan jsonb,
  p_sessions jsonb,
  p_client_request_id text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_caller uuid := auth.uid();
  v_plan_id uuid;
  v_existing_request_id text;
  v_inserted integer := 0;
begin
  if v_caller is not null and v_caller <> p_user_id then
    raise exception 'replace_plan_atomic: caller does not own this plan'
      using errcode = '42501';
  end if;

  if p_plan is null or jsonb_typeof(p_plan) <> 'object' then
    raise exception 'replace_plan_atomic: p_plan must be a JSON object';
  end if;

  if p_sessions is null or jsonb_typeof(p_sessions) <> 'array' then
    raise exception 'replace_plan_atomic: p_sessions must be a JSON array';
  end if;

  -- Serialize concurrent submissions for the same user.
  perform pg_advisory_xact_lock(hashtext('replace_plan_atomic:' || p_user_id::text));

  select id, client_request_id
    into v_plan_id, v_existing_request_id
  from public.plans
  where user_id = p_user_id
  limit 1
  for update;

  -- Idempotency: a duplicate submission (double-click, client retry) with the
  -- same request id returns the already-durable result untouched.
  if v_plan_id is not null
     and p_client_request_id is not null
     and v_existing_request_id is not null
     and v_existing_request_id = p_client_request_id then
    select count(*) into v_inserted
    from public.sessions
    where user_id = p_user_id and plan_id = v_plan_id;

    return jsonb_build_object(
      'plan_id', v_plan_id,
      'sessions_created', v_inserted,
      'idempotent_replay', true
    );
  end if;

  if v_plan_id is null then
    insert into public.plans (user_id, race_date, race_type, plan, client_request_id)
    values (p_user_id, p_race_date, p_race_type, p_plan, p_client_request_id)
    returning id into v_plan_id;
  else
    update public.plans
    set race_date = p_race_date,
        race_type = p_race_type,
        plan = p_plan,
        client_request_id = p_client_request_id
    where id = v_plan_id;
  end if;

  -- Replace only the superseded generated plan's sessions. Manual sessions
  -- (plan_id IS NULL) and any sessions belonging to other plans survive.
  delete from public.sessions
  where user_id = p_user_id
    and plan_id = v_plan_id;

  insert into public.sessions
    (user_id, plan_id, date, sport, title, session_title, details, duration, status, strava_id, structured_workout, raw)
  select
    p_user_id,
    v_plan_id,
    (s->>'date')::date,
    s->>'sport',
    s->>'title',
    coalesce(s->>'session_title', s->>'title'),
    s->>'details',
    nullif(s->>'duration', '')::numeric,
    coalesce(s->>'status', 'planned'),
    null,
    null,
    s->'raw'
  from jsonb_array_elements(p_sessions) as s;

  get diagnostics v_inserted = row_count;

  return jsonb_build_object(
    'plan_id', v_plan_id,
    'sessions_created', v_inserted,
    'idempotent_replay', false
  );
end;
$$;

revoke all on function public.replace_plan_atomic(uuid, date, text, jsonb, jsonb, text) from public;
grant execute on function public.replace_plan_atomic(uuid, date, text, jsonb, jsonb, text) to authenticated, service_role;
