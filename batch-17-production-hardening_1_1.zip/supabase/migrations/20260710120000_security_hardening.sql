-- 20260710120000_security_hardening.sql
--
-- Additive-only production hardening:
--   1. api_usage_events: durable per-user usage limiting for LLM routes.
--   2. completed_sessions.session_id: stable, server-authoritative completion
--      identity (FK to sessions) with a uniqueness constraint, plus an
--      unambiguous backfill from legacy date/title rows.
--   3. plans.client_request_id + plans.updated_at: idempotent plan replacement
--      and optimistic-concurrency protection for enrichment writes.
--
-- The repository does not contain the full historical schema, so every
-- statement is guarded to be safe on both production and fresh databases.

-- ---------------------------------------------------------------------------
-- 1. api_usage_events
-- ---------------------------------------------------------------------------
create table if not exists public.api_usage_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  route text not null,
  created_at timestamptz not null default now()
);

create index if not exists api_usage_events_user_route_created_idx
  on public.api_usage_events (user_id, route, created_at desc);

-- Service-role only: enable RLS with no policies so the anon/user roles
-- cannot read or write usage counters.
alter table public.api_usage_events enable row level security;

-- ---------------------------------------------------------------------------
-- 2. completed_sessions.session_id
-- ---------------------------------------------------------------------------
do $$
begin
  if to_regclass('public.completed_sessions') is not null
     and to_regclass('public.sessions') is not null then

    if not exists (
      select 1 from information_schema.columns
      where table_schema = 'public'
        and table_name = 'completed_sessions'
        and column_name = 'session_id'
    ) then
      alter table public.completed_sessions
        add column session_id uuid references public.sessions(id) on delete set null;
    end if;

    -- One completion row per session. A plain (non-partial) unique index is
    -- required so PostgREST upserts can use ON CONFLICT (session_id); Postgres
    -- treats NULLs as distinct, so legacy rows without session_id are exempt.
    if not exists (
      select 1 from pg_indexes
      where schemaname = 'public'
        and indexname = 'completed_sessions_session_id_unique'
    ) then
      create unique index completed_sessions_session_id_unique
        on public.completed_sessions (session_id);
    end if;

    create index if not exists completed_sessions_user_date_idx
      on public.completed_sessions (user_id, date);

    -- Backfill: link legacy rows only where (user_id, date, title) resolves to
    -- exactly one session AND no other completion row already claims it.
    update public.completed_sessions cs
    set session_id = match.session_id
    from (
      select cs2.id as completed_id, min(s.id::text)::uuid as session_id
      from public.completed_sessions cs2
      join public.sessions s
        on s.user_id = cs2.user_id
       and s.date = cs2.date
       and s.title = cs2.session_title
      where cs2.session_id is null
      group by cs2.id
      having count(s.id) = 1
    ) match
    where cs.id = match.completed_id
      and cs.session_id is null
      and not exists (
        select 1 from public.completed_sessions other
        where other.session_id = match.session_id
      );
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- 3. plans idempotency + concurrency columns
-- ---------------------------------------------------------------------------
do $$
begin
  if to_regclass('public.plans') is not null then
    if not exists (
      select 1 from information_schema.columns
      where table_schema = 'public' and table_name = 'plans' and column_name = 'client_request_id'
    ) then
      alter table public.plans add column client_request_id text;
    end if;

    if not exists (
      select 1 from information_schema.columns
      where table_schema = 'public' and table_name = 'plans' and column_name = 'updated_at'
    ) then
      alter table public.plans add column updated_at timestamptz not null default now();
    end if;
  end if;
end $$;

create or replace function public.traingpt_touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
begin
  if to_regclass('public.plans') is not null then
    if not exists (
      select 1 from pg_trigger
      where tgname = 'plans_touch_updated_at'
        and tgrelid = 'public.plans'::regclass
    ) then
      create trigger plans_touch_updated_at
        before update on public.plans
        for each row execute function public.traingpt_touch_updated_at();
    end if;
  end if;
end $$;
