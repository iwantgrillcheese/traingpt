import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { authorizeCronRequest } from '@/lib/server/cronAuth';

function makeReq(headers: Record<string, string> = {}, url = 'https://traingpt.co/api/adapt-week') {
  return new Request(url, { headers });
}

const ORIGINAL_ENV = { ...process.env };

describe('authorizeCronRequest', () => {
  beforeEach(() => {
    process.env = { ...ORIGINAL_ENV };
    delete process.env.CRON_SECRET;
    delete process.env.ALLOW_INSECURE_CRON;
    process.env.NODE_ENV = 'production';
    process.env.VERCEL_ENV = 'production';
  });

  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
  });

  it('fails closed in production when CRON_SECRET is missing', () => {
    const result = authorizeCronRequest(makeReq(), 'test');
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.status).toBe(503);
  });

  it('rejects requests with no authorization header', () => {
    process.env.CRON_SECRET = 'topsecret';
    const result = authorizeCronRequest(makeReq(), 'test');
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.status).toBe(401);
  });

  it('rejects an incorrect bearer token', () => {
    process.env.CRON_SECRET = 'topsecret';
    const result = authorizeCronRequest(makeReq({ authorization: 'Bearer wrong' }), 'test');
    expect(result.ok).toBe(false);
  });

  it('accepts a correct bearer token', () => {
    process.env.CRON_SECRET = 'topsecret';
    const result = authorizeCronRequest(makeReq({ authorization: 'Bearer topsecret' }), 'test');
    expect(result.ok).toBe(true);
  });

  it('rejects query-parameter secrets in production', () => {
    process.env.CRON_SECRET = 'topsecret';
    const result = authorizeCronRequest(
      makeReq({}, 'https://traingpt.co/api/adapt-week?secret=topsecret'),
      'test'
    );
    expect(result.ok).toBe(false);
  });

  it('never leaks the secret in the failure payload', () => {
    process.env.CRON_SECRET = 'topsecret';
    const result = authorizeCronRequest(makeReq({ authorization: 'Bearer nope' }), 'test');
    expect(JSON.stringify(result)).not.toContain('topsecret');
  });

  it('allows local development only with explicit opt-in', () => {
    process.env.NODE_ENV = 'development';
    process.env.VERCEL_ENV = 'development';

    // Without opt-in: rejected even in dev.
    expect(authorizeCronRequest(makeReq(), 'test').ok).toBe(false);

    // With opt-in: allowed for local testing.
    process.env.ALLOW_INSECURE_CRON = 'true';
    expect(authorizeCronRequest(makeReq(), 'test').ok).toBe(true);
  });
});
