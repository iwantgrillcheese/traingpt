import { describe, expect, it } from 'vitest';
import { checkAndConsumeRateLimit, ruleForRoute } from '@/lib/server/rateLimit';

/** Fake of the api_usage_events queries used by the limiter. */
function makeFakeClient() {
  const rows: Array<{ user_id: string; route: string; created_at: string }> = [];

  const client: any = {
    from(table: string) {
      expect(table).toBe('api_usage_events');
      const filters: Array<[string, any]> = [];
      let gteFilter: [string, string] | null = null;

      const builder: any = {
        select() {
          return builder;
        },
        eq(col: string, val: any) {
          filters.push([col, val]);
          return builder;
        },
        gte(col: string, val: string) {
          gteFilter = [col, val];
          return builder;
        },
        insert(row: any) {
          rows.push({ ...row, created_at: new Date().toISOString() });
          return Promise.resolve({ error: null });
        },
        then(resolve: any, reject: any) {
          const count = rows.filter(
            (r) =>
              filters.every(([col, val]) => (r as any)[col] === val) &&
              (!gteFilter || r.created_at >= gteFilter[1])
          ).length;
          return Promise.resolve({ count, error: null }).then(resolve, reject);
        },
      };
      return builder;
    },
  };

  return { client, rows };
}

describe('checkAndConsumeRateLimit', () => {
  it('allows up to the limit, then returns 429 semantics', async () => {
    const { client } = makeFakeClient();
    const rule = { limit: 3, windowSeconds: 3600 };

    for (let i = 0; i < 3; i++) {
      const decision = await checkAndConsumeRateLimit({
        userId: 'u1',
        route: '/api/finalize-plan',
        rule,
        client,
      });
      expect(decision.allowed).toBe(true);
    }

    const blocked = await checkAndConsumeRateLimit({
      userId: 'u1',
      route: '/api/finalize-plan',
      rule,
      client,
    });
    expect(blocked.allowed).toBe(false);
    if (!blocked.allowed) {
      expect(blocked.retryAfterSeconds).toBeGreaterThan(0);
      expect(blocked.message).toMatch(/limit/i);
    }
  });

  it('limits are per user', async () => {
    const { client } = makeFakeClient();
    const rule = { limit: 1, windowSeconds: 3600 };

    expect((await checkAndConsumeRateLimit({ userId: 'u1', route: '/r', rule, client })).allowed).toBe(true);
    expect((await checkAndConsumeRateLimit({ userId: 'u1', route: '/r', rule, client })).allowed).toBe(false);
    // A different user is unaffected.
    expect((await checkAndConsumeRateLimit({ userId: 'u2', route: '/r', rule, client })).allowed).toBe(true);
  });

  it('limits are per route', async () => {
    const { client } = makeFakeClient();
    const rule = { limit: 1, windowSeconds: 3600 };

    expect((await checkAndConsumeRateLimit({ userId: 'u1', route: '/a', rule, client })).allowed).toBe(true);
    expect((await checkAndConsumeRateLimit({ userId: 'u1', route: '/b', rule, client })).allowed).toBe(true);
  });

  it('fails open when no service client is available', async () => {
    const decision = await checkAndConsumeRateLimit({ userId: 'u1', route: '/r', client: null });
    expect(decision.allowed).toBe(true);
  });

  it('has sane defaults and env overrides', () => {
    const base = ruleForRoute('/api/finalize-plan');
    expect(base.limit).toBeGreaterThan(0);

    process.env.RATE_LIMIT_API_FINALIZE_PLAN__LIMIT = '2';
    const overridden = ruleForRoute('/api/finalize-plan');
    expect(overridden.limit).toBe(2);
    delete process.env.RATE_LIMIT_API_FINALIZE_PLAN__LIMIT;
  });
});
