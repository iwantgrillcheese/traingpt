-- tests/sql/replace_plan_atomic.test.sql
--
-- Integration test for the atomic plan replacement function, runnable against
-- any throwaway Postgres database:
--
--   createdb traingpt_test
--   psql -v ON_ERROR_STOP=1 -d traingpt_test -f tests/sql/replace_plan_atomic.test.sql
--
-- The script builds a minimal schema (plans / sessions), stubs auth.uid(),
-- applies the migration function, and asserts:
--   1. successful replacement
--   2. manual sessions (plan_id IS NULL) are preserved
--   3. duplicate submissions (same client_request_id) are idempotent
--   4. an insert failure rolls the whole replacement back (old schedule kept)
--   5. a caller cannot replace another user's plan

begin;

-- ---------------------------------------------------------------- schema ---
create extension if not exists pgcrypto;

-- Supabase roles referenced by the migration's GRANTs.
do $$ begin
  if not exists (select 1 from pg_roles where rolname = 'authenticated') then create role authenticated; end if;
  if not exists (select 1 from pg_roles where rolname = 'service_role') then create role service_role; end if;
end $$;

create schema if not exists auth;
create or replace function auth.uid() returns uuid language sql stable as $$
  select nullif(current_setting('test.uid', true), '')::uuid
$$;

create table public.plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique,
  race_date date,
  race_type text,
  plan jsonb,
  client_request_id text,
  updated_at timestamptz not null default now()
);

create table public.sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  plan_id uuid references public.plans(id) on delete cascade,
  date date not null,
  sport text,
  title text,
  session_title text,
  details text,
  duration numeric,
  status text default 'planned',
  strava_id text,
  structured_workout jsonb,
  raw jsonb
);

-- --------------------------------------------------------------- function ---
\i supabase/migrations/20260710121000_replace_plan_atomic.sql

-- ------------------------------------------------------------------ setup ---
select set_config('test.uid', '11111111-1111-1111-1111-111111111111', false);

-- A manual session that must survive every replacement.
insert into public.sessions (user_id, plan_id, date, sport, title)
values ('11111111-1111-1111-1111-111111111111', null, current_date, 'run', 'Manual parkrun');

-- ------------------------------------------------------- 1. first creation ---
do $$
declare r jsonb;
begin
  r := public.replace_plan_atomic(
    '11111111-1111-1111-1111-111111111111',
    (current_date + 90)::date,
    'Half Ironman (70.3)',
    '{"planType":"triathlon","weeks":[]}'::jsonb,
    jsonb_build_array(
      jsonb_build_object('date', current_date::text, 'sport', 'bike', 'title', 'Endurance Ride', 'duration', 60),
      jsonb_build_object('date', (current_date + 1)::text, 'sport', 'run', 'title', 'Easy Run', 'duration', 45)
    ),
    'req-1'
  );

  if (r->>'sessions_created')::int <> 2 then
    raise exception 'TEST 1 FAILED: expected 2 sessions created, got %', r->>'sessions_created';
  end if;
  raise notice 'TEST 1 PASSED: successful creation (%)', r;
end $$;

-- --------------------------------------- 2. idempotent duplicate submission ---
do $$
declare r jsonb;
begin
  r := public.replace_plan_atomic(
    '11111111-1111-1111-1111-111111111111',
    (current_date + 90)::date,
    'Half Ironman (70.3)',
    '{"planType":"triathlon","weeks":[]}'::jsonb,
    jsonb_build_array(
      jsonb_build_object('date', current_date::text, 'sport', 'bike', 'title', 'Endurance Ride', 'duration', 60),
      jsonb_build_object('date', (current_date + 1)::text, 'sport', 'run', 'title', 'Easy Run', 'duration', 45)
    ),
    'req-1'
  );

  if (r->>'idempotent_replay')::boolean is not true then
    raise exception 'TEST 2 FAILED: duplicate submission was not replayed idempotently: %', r;
  end if;

  if (select count(*) from public.sessions where user_id = '11111111-1111-1111-1111-111111111111' and plan_id is not null) <> 2 then
    raise exception 'TEST 2 FAILED: duplicate submission duplicated sessions';
  end if;
  raise notice 'TEST 2 PASSED: duplicate submission is idempotent';
end $$;

-- ------------------------------------------ 3. replacement preserves manual ---
do $$
declare r jsonb;
begin
  r := public.replace_plan_atomic(
    '11111111-1111-1111-1111-111111111111',
    (current_date + 120)::date,
    'Olympic',
    '{"planType":"triathlon","weeks":[],"v":2}'::jsonb,
    jsonb_build_array(
      jsonb_build_object('date', current_date::text, 'sport', 'swim', 'title', 'Technique Swim', 'duration', 40)
    ),
    'req-2'
  );

  if (r->>'sessions_created')::int <> 1 then
    raise exception 'TEST 3 FAILED: expected 1 session, got %', r->>'sessions_created';
  end if;

  if not exists (select 1 from public.sessions where title = 'Manual parkrun' and plan_id is null) then
    raise exception 'TEST 3 FAILED: manual session was deleted by replacement';
  end if;

  if exists (select 1 from public.sessions where title = 'Endurance Ride') then
    raise exception 'TEST 3 FAILED: superseded generated sessions were not replaced';
  end if;
  raise notice 'TEST 3 PASSED: replacement swaps generated sessions, preserves manual sessions';
end $$;

-- -------------------------------------------- 4. failure rolls back cleanly ---
do $$
declare r jsonb;
begin
  begin
    -- 'not-a-date' forces the session insert to fail mid-function.
    r := public.replace_plan_atomic(
      '11111111-1111-1111-1111-111111111111',
      (current_date + 150)::date,
      'Sprint',
      '{"planType":"triathlon","weeks":[],"v":3}'::jsonb,
      jsonb_build_array(
        jsonb_build_object('date', 'not-a-date', 'sport', 'run', 'title', 'Broken Session')
      ),
      'req-3'
    );
    raise exception 'TEST 4 FAILED: invalid session insert did not raise';
  exception when others then
    if SQLERRM like 'TEST 4 FAILED%' then raise; end if;
    -- expected failure path
  end;

  -- Old plan + schedule must be fully intact.
  if (select race_type from public.plans where user_id = '11111111-1111-1111-1111-111111111111') <> 'Olympic' then
    raise exception 'TEST 4 FAILED: plan row was mutated by a failed replacement';
  end if;
  if not exists (select 1 from public.sessions where title = 'Technique Swim') then
    raise exception 'TEST 4 FAILED: previous schedule lost after failed replacement';
  end if;
  if not exists (select 1 from public.sessions where title = 'Manual parkrun') then
    raise exception 'TEST 4 FAILED: manual session lost after failed replacement';
  end if;
  raise notice 'TEST 4 PASSED: failed replacement leaves previous plan and schedule intact';
end $$;

-- --------------------------------------------------- 5. cross-user rejected ---
do $$
begin
  begin
    perform public.replace_plan_atomic(
      '99999999-9999-9999-9999-999999999999', -- someone else
      (current_date + 90)::date,
      'Sprint',
      '{}'::jsonb,
      '[]'::jsonb,
      null
    );
    raise exception 'TEST 5 FAILED: cross-user replacement was allowed';
  exception when insufficient_privilege then
    raise notice 'TEST 5 PASSED: cross-user replacement rejected';
  end;
end $$;

rollback;
