import { describe, expect, it } from 'vitest';
import { validatePlanRequest } from '@/lib/validation/planRequest';
import { isFutureDateISO, isValidISODate, todayISOInTimeZone } from '@/lib/server/dates';

function futureDate(days: number) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

const validBody = () => ({
  raceType: 'Half Ironman (70.3)',
  raceDate: futureDate(120),
  planType: 'triathlon',
  maxHours: 10,
});

describe('validatePlanRequest', () => {
  it('accepts a sane request', () => {
    const result = validatePlanRequest(validBody());
    expect(result.ok).toBe(true);
    expect(result.value?.raceType).toBe('Half Ironman (70.3)');
  });

  it('rejects an unsupported race type', () => {
    const result = validatePlanRequest({ ...validBody(), raceType: 'Ultra Beast 500' });
    expect(result.ok).toBe(false);
    expect(result.errors.join(' ')).toMatch(/raceType/);
  });

  it('rejects a race date in the past', () => {
    const result = validatePlanRequest({ ...validBody(), raceDate: '2020-01-01' });
    expect(result.ok).toBe(false);
  });

  it('rejects a race date today', () => {
    const result = validatePlanRequest({ ...validBody(), raceDate: todayISOInTimeZone() });
    expect(result.ok).toBe(false);
  });

  it('rejects a race years in the future (52-week horizon default)', () => {
    const result = validatePlanRequest({ ...validBody(), raceDate: futureDate(3 * 365) });
    expect(result.ok).toBe(false);
    expect(result.errors.join(' ')).toMatch(/weeks/);
  });

  it('rejects maxHours outside 1–30', () => {
    expect(validatePlanRequest({ ...validBody(), maxHours: 0 }).ok).toBe(false);
    expect(validatePlanRequest({ ...validBody(), maxHours: 200 }).ok).toBe(false);
    expect(validatePlanRequest({ ...validBody(), maxHours: 'lots' }).ok).toBe(false);
  });

  it('rejects implausible FTP values', () => {
    expect(validatePlanRequest({ ...validBody(), bikeFTP: 5 }).ok).toBe(false);
    expect(validatePlanRequest({ ...validBody(), bikeFTP: 9999 }).ok).toBe(false);
    expect(validatePlanRequest({ ...validBody(), bikeFTP: 250 }).ok).toBe(true);
  });

  it('caps note and array lengths', () => {
    expect(validatePlanRequest({ ...validBody(), athleteNotes: 'x'.repeat(5000) }).ok).toBe(false);
    expect(
      validatePlanRequest({ ...validBody(), coachingPriorities: Array(50).fill('speed') }).ok
    ).toBe(false);
  });

  it('validates clientRequestId shape', () => {
    expect(validatePlanRequest({ ...validBody(), clientRequestId: 'abc-123_DEF' }).ok).toBe(true);
    expect(validatePlanRequest({ ...validBody(), clientRequestId: 'nope nope' }).ok).toBe(false);
  });
});

describe('date utilities', () => {
  it('validates ISO dates strictly', () => {
    expect(isValidISODate('2026-07-10')).toBe(true);
    expect(isValidISODate('2026-02-30')).toBe(false);
    expect(isValidISODate('July 10')).toBe(false);
  });

  it('treats tomorrow as future and today/yesterday as not future', () => {
    const today = todayISOInTimeZone('America/Los_Angeles');
    expect(isFutureDateISO(today, 'America/Los_Angeles')).toBe(false);

    const tomorrow = new Date(`${today}T12:00:00Z`);
    tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
    expect(isFutureDateISO(tomorrow.toISOString().slice(0, 10), 'America/Los_Angeles')).toBe(true);

    const yesterday = new Date(`${today}T12:00:00Z`);
    yesterday.setUTCDate(yesterday.getUTCDate() - 1);
    expect(isFutureDateISO(yesterday.toISOString().slice(0, 10), 'America/Los_Angeles')).toBe(false);
  });
});
