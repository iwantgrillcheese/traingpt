import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
  createMobileState,
  createWebState,
  parseSignedState,
  sanitizeReturnTo,
  STATE_TTL_MS,
} from '@/lib/server/stravaState';

const ORIGINAL_ENV = { ...process.env };

describe('strava signed state', () => {
  beforeEach(() => {
    process.env = { ...ORIGINAL_ENV };
    process.env.STRAVA_STATE_SECRET = 'unit-test-secret';
    process.env.NODE_ENV = 'test';
    delete process.env.VERCEL_ENV;
  });

  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
  });

  it('round-trips a web state', () => {
    const raw = createWebState({ userId: 'user-1', returnTo: '/plan?step=strava' });
    const parsed = parseSignedState(raw);
    expect(parsed).not.toBeNull();
    expect(parsed?.type).toBe('web');
    expect(parsed?.userId).toBe('user-1');
    if (parsed?.type === 'web') expect(parsed.returnTo).toBe('/plan?step=strava');
  });

  it('round-trips a mobile state', () => {
    const raw = createMobileState({ userId: 'user-2', appRedirect: 'traingpt://strava/callback' });
    const parsed = parseSignedState(raw);
    expect(parsed?.type).toBe('mobile');
    if (parsed?.type === 'mobile') expect(parsed.appRedirect).toBe('traingpt://strava/callback');
  });

  it('rejects unsigned legacy return-path state', () => {
    expect(parseSignedState('/coaching')).toBeNull();
    expect(parseSignedState('/plan?source=strava')).toBeNull();
  });

  it('rejects tampered payloads', () => {
    const raw = createWebState({ userId: 'user-1', returnTo: '/plan' });
    const [kind, encoded, sig] = raw.split('.');
    const forged = Buffer.from(
      JSON.stringify({ type: 'web', userId: 'attacker', returnTo: '/plan', createdAt: Date.now() }),
      'utf8'
    ).toString('base64url');
    expect(parseSignedState(`${kind}.${forged}.${sig}`)).toBeNull();
  });

  it('rejects expired state', () => {
    const raw = createWebState({ userId: 'user-1', returnTo: '/plan' });
    expect(parseSignedState(raw, Date.now() + STATE_TTL_MS + 1000)).toBeNull();
  });

  it('rejects state signed with a different secret', () => {
    const raw = createWebState({ userId: 'user-1', returnTo: '/plan' });
    process.env.STRAVA_STATE_SECRET = 'a-different-secret';
    expect(parseSignedState(raw)).toBeNull();
  });

  it('sanitizes unsafe return paths', () => {
    expect(sanitizeReturnTo('//evil.com')).toBe('/coaching');
    expect(sanitizeReturnTo('https://evil.com')).toBe('/coaching');
    expect(sanitizeReturnTo(undefined)).toBe('/coaching');
    expect(sanitizeReturnTo('/settings')).toBe('/settings');
  });

  it('refuses to sign with a dev secret in production', () => {
    delete process.env.STRAVA_STATE_SECRET;
    delete process.env.NEXTAUTH_SECRET;
    process.env.NODE_ENV = 'production';
    process.env.VERCEL_ENV = 'production';
    expect(() => createWebState({ userId: 'u', returnTo: '/plan' })).toThrow();
  });
});
