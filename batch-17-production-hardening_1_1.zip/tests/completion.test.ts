import { beforeEach, describe, expect, it } from 'vitest';
import { applyCompletion } from '@/lib/server/completion';
import { todayISOInTimeZone } from '@/lib/server/dates';

/**
 * Minimal in-memory fake of the Supabase client covering only the query
 * shapes lib/server/completion.ts uses:
 *   sessions:            select().eq()...maybeSingle() / .limit(n)
 *   completed_sessions:  delete().eq()/.is() chains, upsert(row, {onConflict})
 */
type Row = Record<string, any>;

function makeFakeSupabase(seed: { sessions: Row[]; completed: Row[] }) {
  const db = {
    sessions: [...seed.sessions],
    completed_sessions: [...seed.completed],
  };

  function matches(row: Row, filters: Array<[string, any, 'eq' | 'is']>) {
    return filters.every(([col, val]) => (row[col] ?? null) === val);
  }

  function from(table: 'sessions' | 'completed_sessions') {
    const filters: Array<[string, any, 'eq' | 'is']> = [];
    let mode: 'select' | 'delete' = 'select';

    const builder: any = {
      select() {
        mode = 'select';
        return builder;
      },
      delete() {
        mode = 'delete';
        return builder;
      },
      eq(col: string, val: any) {
        filters.push([col, val, 'eq']);
        return builder;
      },
      is(col: string, val: any) {
        filters.push([col, val, 'is']);
        return builder;
      },
      maybeSingle() {
        const rows = db[table].filter((r) => matches(r, filters));
        return Promise.resolve({ data: rows[0] ?? null, error: null });
      },
      limit(n: number) {
        const rows = db[table].filter((r) => matches(r, filters)).slice(0, n);
        return Promise.resolve({ data: rows, error: null });
      },
      upsert(row: Row, opts?: { onConflict?: string }) {
        const key = opts?.onConflict ?? 'id';
        const idx = db[table].findIndex((r) => r[key] != null && r[key] === row[key]);
        if (idx >= 0) db[table][idx] = { ...db[table][idx], ...row };
        else db[table].push({ ...row });
        return Promise.resolve({ data: null, error: null });
      },
      then(resolve: any, reject: any) {
        // Awaiting a bare delete() chain executes it.
        if (mode === 'delete') {
          const before = db[table].length;
          db[table] = db[table].filter((r) => !matches(r, filters));
          return Promise.resolve({ data: null, error: null, count: before - db[table].length }).then(
            resolve,
            reject
          );
        }
        const rows = db[table].filter((r) => matches(r, filters));
        return Promise.resolve({ data: rows, error: null }).then(resolve, reject);
      },
    };

    return builder;
  }

  return { client: { from } as any, db };
}

const USER = '11111111-1111-1111-1111-111111111111';
const OTHER_USER = '22222222-2222-2222-2222-222222222222';
const SESSION_ID = '33333333-3333-3333-3333-333333333333';
const OTHER_SESSION_ID = '44444444-4444-4444-4444-444444444444';

const today = todayISOInTimeZone('America/Los_Angeles');
const tomorrow = (() => {
  const d = new Date(`${today}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
})();

let fake: ReturnType<typeof makeFakeSupabase>;

beforeEach(() => {
  fake = makeFakeSupabase({
    sessions: [
      { id: SESSION_ID, user_id: USER, date: today, title: 'Threshold Run' },
      { id: OTHER_SESSION_ID, user_id: OTHER_USER, date: today, title: 'Threshold Run' },
    ],
    completed: [],
  });
});

describe('applyCompletion', () => {
  it('marks a session done via sessionId', async () => {
    const result = await applyCompletion({
      supabase: fake.client,
      userId: USER,
      payload: { sessionId: SESSION_ID },
      status: 'done',
    });
    expect(result.ok).toBe(true);
    expect(fake.db.completed_sessions).toHaveLength(1);
    expect(fake.db.completed_sessions[0]).toMatchObject({ session_id: SESSION_ID, status: 'done' });
  });

  it("rejects another user's session (ownership)", async () => {
    const result = await applyCompletion({
      supabase: fake.client,
      userId: USER,
      payload: { sessionId: OTHER_SESSION_ID },
      status: 'done',
    });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.status).toBe(404);
    expect(fake.db.completed_sessions).toHaveLength(0);
  });

  it('rejects future workouts server-side', async () => {
    fake.db.sessions.push({ id: '55555555-5555-5555-5555-555555555555', user_id: USER, date: tomorrow, title: 'Long Ride' });
    const result = await applyCompletion({
      supabase: fake.client,
      userId: USER,
      payload: { sessionId: '55555555-5555-5555-5555-555555555555' },
      status: 'done',
    });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.status).toBe(400);
  });

  it('duplicate calls do not create duplicate rows (atomic upsert)', async () => {
    for (let i = 0; i < 3; i++) {
      const result = await applyCompletion({
        supabase: fake.client,
        userId: USER,
        payload: { sessionId: SESSION_ID },
        status: 'done',
      });
      expect(result.ok).toBe(true);
    }
    expect(fake.db.completed_sessions).toHaveLength(1);
  });

  it('undo is idempotent', async () => {
    await applyCompletion({ supabase: fake.client, userId: USER, payload: { sessionId: SESSION_ID }, status: 'done' });
    for (let i = 0; i < 2; i++) {
      const result = await applyCompletion({
        supabase: fake.client,
        userId: USER,
        payload: { sessionId: SESSION_ID, undo: true },
        status: 'done',
      });
      expect(result.ok).toBe(true);
      if (result.ok) expect(result.active).toBe(false);
    }
    expect(fake.db.completed_sessions).toHaveLength(0);
  });

  it('undo also clears pre-migration legacy rows (no session_id)', async () => {
    fake.db.completed_sessions.push({
      user_id: USER,
      session_id: null,
      date: today,
      session_title: 'Threshold Run',
      status: 'done',
    });
    const result = await applyCompletion({
      supabase: fake.client,
      userId: USER,
      payload: { sessionId: SESSION_ID, undo: true },
      status: 'done',
    });
    expect(result.ok).toBe(true);
    expect(fake.db.completed_sessions).toHaveLength(0);
  });

  it('legacy date+title identity resolves an unambiguous session', async () => {
    const result = await applyCompletion({
      supabase: fake.client,
      userId: USER,
      payload: { session_date: today, session_title: 'Threshold Run' },
      status: 'skipped',
    });
    expect(result.ok).toBe(true);
    expect(fake.db.completed_sessions[0]).toMatchObject({ session_id: SESSION_ID, status: 'skipped' });
  });

  it('legacy identity with two same-title sessions is a 409, not a guess', async () => {
    fake.db.sessions.push({ id: '66666666-6666-6666-6666-666666666666', user_id: USER, date: today, title: 'Threshold Run' });
    const result = await applyCompletion({
      supabase: fake.client,
      userId: USER,
      payload: { session_date: today, session_title: 'Threshold Run' },
      status: 'done',
    });
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.status).toBe(409);
  });

  it('same-title sessions on the same day are independently completable by id', async () => {
    const secondId = '77777777-7777-7777-7777-777777777777';
    fake.db.sessions.push({ id: secondId, user_id: USER, date: today, title: 'Threshold Run' });

    await applyCompletion({ supabase: fake.client, userId: USER, payload: { sessionId: SESSION_ID }, status: 'done' });
    await applyCompletion({ supabase: fake.client, userId: USER, payload: { sessionId: secondId }, status: 'done' });

    expect(fake.db.completed_sessions).toHaveLength(2);
    const ids = fake.db.completed_sessions.map((r) => r.session_id).sort();
    expect(ids).toEqual([SESSION_ID, secondId].sort());
  });
});
