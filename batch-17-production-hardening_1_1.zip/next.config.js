const path = require('path');

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['lh3.googleusercontent.com'], // external image domains
  },
  webpack: (config) => {
    config.resolve.alias['@'] = path.resolve(__dirname); // use '@/components' etc.
    return config;
  },
};

module.exports = nextConfig;
