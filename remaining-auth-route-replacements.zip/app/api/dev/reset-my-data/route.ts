import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { AuthError, createRouteSupabaseClient, requireUser } from '@/lib/supabase/server';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ALLOWED_EMAILS = ['me@cameronmcdiarmid.com', 'cameron.mcdiarmid@gmail.com'];

function resetIsAllowedByEnv(): boolean {
  if (process.env.DISABLE_DEV_RESET === 'true') return false;
  return true;
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const confirm = typeof body?.confirm === 'string' ? body.confirm : '';

    const supabase = await createRouteSupabaseClient();
    const user = await requireUser(supabase);

    if (!resetIsAllowedByEnv()) {
      return NextResponse.json(
        {
          ok: false,
          error: 'Reset endpoint is disabled by DISABLE_DEV_RESET=true',
          reason: 'env_guard',
        },
        { status: 403 }
      );
    }

    const email = (user.email || '').toLowerCase();
    if (!ALLOWED_EMAILS.includes(email)) {
      return NextResponse.json(
        { ok: false, error: 'Forbidden', reason: 'email_not_allowlisted', email },
        { status: 403 }
      );
    }

    if (confirm !== 'RESET') {
      return NextResponse.json(
        { ok: false, error: 'Confirmation required (confirm=RESET)' },
        { status: 400 }
      );
    }

    const supabaseUrl = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !serviceRoleKey) {
      return NextResponse.json(
        { ok: false, error: 'Server is missing Supabase service role configuration' },
        { status: 500 }
      );
    }

    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const userId = user.id;

    const countForUser = async (table: string) => {
      const { count, error } = await admin
        .from(table)
        .select('id', { head: true, count: 'exact' })
        .eq('user_id', userId);

      if (error) throw new Error(`${table}: ${error.message}`);
      return count ?? 0;
    };

    const deleted = {
      completed_sessions: await countForUser('completed_sessions'),
      strava_activities: await countForUser('strava_activities'),
      sessions: await countForUser('sessions'),
      plans: await countForUser('plans'),
    };

    const { error: completedErr } = await admin
      .from('completed_sessions')
      .delete()
      .eq('user_id', userId);
    if (completedErr) throw new Error(`completed_sessions: ${completedErr.message}`);

    const { error: stravaErr } = await admin
      .from('strava_activities')
      .delete()
      .eq('user_id', userId);
    if (stravaErr) throw new Error(`strava_activities: ${stravaErr.message}`);

    const { error: sessionsErr } = await admin.from('sessions').delete().eq('user_id', userId);
    if (sessionsErr) throw new Error(`sessions: ${sessionsErr.message}`);

    const { error: plansErr } = await admin.from('plans').delete().eq('user_id', userId);
    if (plansErr) throw new Error(`plans: ${plansErr.message}`);

    return NextResponse.json({
      ok: true,
      user_id: userId,
      deleted,
    });
  } catch (error: any) {
    console.error('[dev/reset-my-data] failed', error?.message, error);

    if (error instanceof AuthError) {
      return NextResponse.json(
        { ok: false, error: error.message },
        { status: error.status }
      );
    }

    return NextResponse.json(
      { ok: false, error: error?.message || 'Reset failed' },
      { status: 500 }
    );
  }
}
